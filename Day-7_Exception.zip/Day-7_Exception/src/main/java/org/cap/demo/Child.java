package org.cap.demo;

import java.io.FileNotFoundException;

public class Child extends Parent {

	@Override
	public void print() throws FileNotFoundException,InterruptedException,NumberFormatException {
		// TODO Auto-generated method stub
System.out.println("This is child class method");	}

}
