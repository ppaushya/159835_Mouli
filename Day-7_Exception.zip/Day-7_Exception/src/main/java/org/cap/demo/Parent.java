package org.cap.demo;

import java.io.FileNotFoundException;

public class Parent {
public void print() throws FileNotFoundException,InterruptedException,ArithmeticException {
	System.out.println("Hello");
	
}
}
