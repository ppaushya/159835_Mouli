package org.cap.demo;

public class Calculation {
public void calculateMethod() throws NumberFormatException,ArithmeticException,NullPointerException {
	Integer num1=100;
	Integer num2=2;
	Integer ans=null;
	//try {
		ans=num1+num2;
		System.out.println("Answer"+ans);
	//	try {
			String num="0";
			int res=ans/Integer.parseInt(num);
			System.out.println("Result"+res);
	//	}catch(NumberFormatException e)
		//{
		//	System.out.println("Hey numbers doesnot match");
		//}
	//}
	//catch(Exception e){//not a good practice
//		e.printStackTrace();
		
}
}
