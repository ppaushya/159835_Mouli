package org.cap.demo;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Validation {
 static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String empId;
System.out.println("eNTER eMPLOYEE Id");
empId=scan.next();
if(empId.matches("\\d{5}_(FS|TS|IN)")){
	System.out.println("Valid Id");
}else
	System.out.println("Please try again");

Pattern p=Pattern.compile("\\d{5}_(FS|TS|IN)");
Matcher match=p.matcher(empId);
System.out.println(match.find());


	}

}
