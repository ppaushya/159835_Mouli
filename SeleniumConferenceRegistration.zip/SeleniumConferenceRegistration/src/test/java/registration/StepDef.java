package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import bean.PaymentBean;
import bean.RegistrationBean;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webdriver;
	private WebElement webelement, element;
	private String message;
	private RegistrationBean register;
	private PaymentBean payment;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\mokotha\\Downloads\\chromedriver.exe");
		webdriver = new ChromeDriver();
		register=new RegistrationBean(webdriver);
		payment=new PaymentBean(webdriver);
	}

	@Given("^Open ConferenceRegistartion\\.html page$")
	public void open_ConferenceRegistartion_html_page() throws Throwable {
		webdriver.get("file:///D:/Users/mokotha/Desktop/Conferencebooking/ConferenceRegistartion.html");
	}

	@Given("^provide correct details$")
	public void provide_correct_details() throws Throwable {
		// 3. page name
		if (!webdriver.getTitle().startsWith("Conference Registartion")) {
			webdriver.quit();
		}
		sleepForSomeTime();

		// 4. heading
		webelement = webdriver.findElement(By.xpath("/html/body/h4"));
		if (!webelement.getText().equals("Step 1: Personal Details")) {
			webdriver.quit();
		}
		sleepForSomeTime();

		// 5. first name
	
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the First Name");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		
		register.setFirstName("Moulya");
		

		// 6. last name
		
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Last Name");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		register.setLastName("Kotha");
		
		// 7. email
		
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Email");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		register.setEmail("mou@gmail.com");
		
		

		// 8. contact no
	
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Contact No.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		register.setPhone("5987654321");
		

		// 9. correct phone number
		
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please enter valid Contact no.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).clear();
        register.setPhone("9876543212");

		// 10. number of people
	
		register.setNext();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Number of people attending");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		register.setNumberOfppl();
		
		// 11. street address
		
		register.setAddress1("Central");
		sleepForSomeTime();
		register.setAddress2("Central Avenue");
		
		sleepForSomeTime();

		// 12. city
	
		register.setCity();
		sleepForSomeTime();

		// 13. state
		register.setState();
		sleepForSomeTime();

		// 14. Conference full-Access(member)
		register.setMemberStatus1();
		sleepForSomeTime();

		

	}

	@When("^click next link$")
	public void click_next_link() throws Throwable {
		// 16. next
		register.setNext();

		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Personal details are validated.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
	}

	@Then("^navigate to PaymentDetails\\.html$")
	public void navigate_to_PaymentDetails_html() throws Throwable {
		// 16. next
		message = webdriver.getCurrentUrl();
		assertEquals(message, "file:///D:/Users/mokotha/Desktop/Conferencebooking/PaymentDetails.html");
		sleepForSomeTime();

		webdriver.quit();
	}

	@Given("^Open PaymentDetails\\.html page$")
	public void open_PaymentDetails_html_page() throws Throwable {
		// 16. next
		webdriver.get("file:///D:/Users/mokotha/Desktop/Conferencebooking/PaymentDetails.html");
		
		
	}

	@Given("^correct details provided$")
	public void correct_details_provided() throws Throwable {
		// 17. first name
		// 18. last name
	
		payment.setTxtFN("Moulya Kotha");
		sleepForSomeTime();

		// 19. card number
		
		payment.setDebit("7895632589657412");
		sleepForSomeTime();

		// 20. cvv
		payment.setCvv("040");
		sleepForSomeTime();

		// 21. Expiration Month
		payment.setMonth("08");
		sleepForSomeTime();

		// 22. Expiration Year
		payment.setYear("2023");
		sleepForSomeTime();

	}

	@When("^click on Make Payment button$")
	public void click_on_Make_Payment_button() throws Throwable {
		// 23. register
		payment.setMakePayment();
	}

	@Then("^show successful message$")
	public void show_successful_message() throws Throwable {
		// 23. register
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Conference Room Booking successfully done!!!");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();

		webdriver.quit();
	}
	
	private void sleepForSomeTime() {
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
