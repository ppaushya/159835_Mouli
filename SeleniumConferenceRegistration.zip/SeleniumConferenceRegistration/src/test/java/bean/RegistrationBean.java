package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationBean {
	
	private WebDriver driver;
	
	@FindBy(id="txtFirstName",how=How.ID)
	private WebElement firstName;
	@FindBy(id="txtLastName",how=How.ID)
	private WebElement lastName;
	@FindBy(id="txtEmail",how=How.ID)
	private WebElement email;
	@FindBy(id="txtPhone",how=How.ID)
	private WebElement phone;
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/select/option[2]",how=How.XPATH)
	private WebElement numberOfppl;
	@FindBy(id="txtAddress1",how=How.ID)
	private WebElement address1;
	@FindBy(id="txtAddress2",how=How.ID)
	private WebElement address2;
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select/option[4]",how=How.XPATH)
	private WebElement city;
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select/option[4]",how=How.XPATH)
	private WebElement state;
	@FindBy(xpath="/html/body/form/table/tbody/tr[12]/td[2]/input",how=How.XPATH)
	private WebElement memberStatus1;
	@FindBy(xpath="/html/body/form/table/tbody/tr[13]/td[2]/input",how=How.XPATH)
	private WebElement memberStatus2;
	@FindBy(xpath="/html/body/form/table/tbody/tr[14]/td/a",how=How.XPATH)
	private WebElement next;
	
	public RegistrationBean() {
		
	}
public RegistrationBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	


	public RegistrationBean(WebDriver driver, WebElement firstName, WebElement lastName, WebElement email, WebElement phone,
		WebElement numberOfppl, WebElement address1, WebElement address2, WebElement city, WebElement state,
		WebElement memberStatus1, WebElement memberStatus2, WebElement next) {
	super();
	this.driver = driver;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.phone = phone;
	this.numberOfppl = numberOfppl;
	this.address1 = address1;
	this.address2 = address2;
	this.city = city;
	this.state = state;
	this.memberStatus1 = memberStatus1;
	this.memberStatus2 = memberStatus2;
	this.next = next;
}
	
	
	public String getFirstName() {
		return this.firstName.getText();
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return this.lastName.getText();
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	


	
	public String getEmail() {
		return this.email.getText();
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}
	public String getPhone() {
		return this.phone.getText();
	}
	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}
	public String getNumberOfppl() {
		return this.numberOfppl.getText();
	}
	public void setNumberOfppl() {
		this.numberOfppl.click();
	}
	public String getAddress1() {
		return this.address1.getText();
	}
	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}
	public String getAddress2() {
		return this.address2.getText();
	}
	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	public String getCity() {
		return this.city.getText();
	}
	public void setCity() {
		this.city.click();
	}
	public String getState() {
		return this.state.getText();
	}
	public void setState() {
		this.state.click();
	}
	public String getMemberStatus1() {
		return this.memberStatus1.getText();
	}
	public void setMemberStatus1() {
		this.memberStatus1.click();
	}
	public String getMemberStatus2() {
		return this.memberStatus2.getText();
	}
	public void setMemberStatus2() {
		this.memberStatus2.click();
	}
	
	
	public String getNext() {
		return this.next.getText();
	}



	public void setNext() {
		this.next.click();
	}
	
	

}
