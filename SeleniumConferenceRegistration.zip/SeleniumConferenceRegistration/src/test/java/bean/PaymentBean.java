package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentBean {
	
	private WebDriver driver;
	@FindBy(id="txtCardholderName",how=How.ID)
	private WebElement txtFN;
	@FindBy(id="txtDebit",how=How.ID)
	private WebElement debit;
	@FindBy(id="txtCvv",how=How.ID)
	private WebElement cvv;
	@FindBy(id="txtMonth",how=How.ID)
	private WebElement month;
	@FindBy(id="txtYear",how=How.ID)
	private WebElement year;
	@FindBy(id="btnPayment",how=How.ID)
	private WebElement makePayment;
	public PaymentBean() {
		
	}
     public PaymentBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver,this);
	}
	public PaymentBean(WebDriver driver, WebElement txtFN, WebElement debit, WebElement cvv, WebElement month,
			WebElement year, WebElement makePayment) {
		super();
		this.driver = driver;
		this.txtFN = txtFN;
		this.debit = debit;
		this.cvv = cvv;
		this.month = month;
		this.year = year;
		this.makePayment = makePayment;
	}
	
	public String getTxtFN() {
		return this.txtFN.getText();
	}
	public void setTxtFN(String txtFN) {
		this.txtFN.sendKeys(txtFN);
	}
	public String getDebit() {
		return this.debit.getText();
	}
	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}
	public String getCvv() {
		return this.cvv.getText();
	}
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	public String getMonth() {
		return this.month.getText();
	}
	public void setMonth(String month) {
		this.month.sendKeys(month);
	}
	public String getYear() {
		return this.year.getText();
	}
	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	public String getMakePayment() {
		return this.makePayment.getText();
	}
	public void setMakePayment() {
		this.makePayment.click();
	}
	@Override
	public String toString() {
		return "PaymentBean [driver=" + driver + ", txtFN=" + txtFN + ", debit=" + debit + ", cvv=" + cvv + ", month="
				+ month + ", year=" + year + ", makePayment=" + makePayment + "]";
	}
	

}
