package com.capgemini;
import java.util.*;
public class HashMapDemo {

	public static void main(String[] args) {
		//LinkedHashMap<Integer,String> map=new LinkedHashMap<>();
	Map<Integer,String> map=new Hashtable<>();
		map.put(1,"one");
		map.put(2,"two");
		map.put(5,"mouly");
		map.put(1,"one");
		map.put(1,"three");
		map.put(3,"three");
		//map.put(4,null);
		map.put(167,"three");
		map.put(1777,"three");
		//map.put(null,"three");
		System.out.println(map);
		//to retrieve all the keys
		Set<Integer> k= map.keySet();
		Iterator<Integer> it=k.iterator();
		 while(it.hasNext())
		    {
		    	int key=it.next();
		    	System.out.println(key+"--->"+map.get(key));
		    	
		    }
		 Collection<String> values=map.values();
		 for(String str:values)
		 {
			 System.out.println(str+", ");
		 }
		 //using enumeration
		 Enumeration<String> e=((Hashtable<Integer, String>) map).elements();
		 while(e.hasMoreElements())
		 {
			 System.out.println(e.nextElement());
		 }
		 
	}

}
