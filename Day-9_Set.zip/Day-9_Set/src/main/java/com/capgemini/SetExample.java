package com.capgemini;

import java.util.*;

public class SetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet	<Integer> str=new TreeSet<>();
		str.add(1);
		str.add(2);
		str.add(1111);
		str.add(23);
		str.add(5);
		//str.add(null);
		str.add(1);
		System.out.println(str);

	}

}
