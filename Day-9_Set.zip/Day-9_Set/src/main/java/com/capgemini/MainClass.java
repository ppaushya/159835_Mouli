package com.capgemini;
import java.util.*;
import java.time.LocalDate;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TreeSet<Employee> emp=new TreeSet<>();
		List<Employee> emp=new ArrayList<>();
		emp.add(new Employee(101,"mom","Dad",10000,LocalDate.now()));
		emp.add(new Employee(102,"Jack","Jill",15000,LocalDate.now()));
		emp.add(new Employee(103,"Moulya","Ram",20000,LocalDate.now()));
		
		emp.add(new Employee(105,"Moulya","Aslesha",70000,LocalDate.now()));
		emp.add(new Employee(101,"mom","Dad",10000,LocalDate.now()));
		emp.add(new Employee(104,"Venkat","Sairam",35000,LocalDate.now()));
	Collections.sort(emp);
		Iterator<Employee> iterator=emp.iterator();
		
		    while(iterator.hasNext())
		    {
		    	Employee employee=iterator.next();
		    	System.out.println(employee);
		    	
		    }
		    System.out.println("============================");
			Collections.sort(emp,new SortByFirstName());
			Iterator<Employee> iterator1=emp.iterator();
			
		    while(iterator1.hasNext())
		    {
		    	Employee employee=iterator1.next();
		    	System.out.println(employee);
		    	
		    }
		    Comparator<Employee> sortbysal=  new Comparator<Employee>(){

				@Override
				public int compare(Employee o1, Employee o2) {
					if(o1.getSalary()>o2.getSalary())
						return 1;
					else if(o1.getSalary()<o2.getSalary())
						return -1;
					else
					    return 0;
				}
		    	
		    };
		    System.out.println("============================");
			Collections.sort(emp,sortbysal);
			Iterator<Employee> iterator3=emp.iterator();
			
		    while(iterator3.hasNext())
		    {
		    	Employee employee=iterator3.next();
		    	System.out.println(employee);
		    	
		    }

		    System.out.println("============================");
			Collections.sort(emp,new SortByFirstName());
			Iterator<Employee> iterator2=emp.iterator();
			
		    while(iterator2.hasNext())
		    {
		    	Employee employee=iterator2.next();
		    	System.out.println(employee);
		    	
		    }
	}

}
