package com.capgemini;
import java.util.*;
public class MainMap {

	public static void main(String[] args) {
		
          TreeMap<Customer,Address> map=new TreeMap<>();
          map.put(new Customer(1234,"moulya","34545","DFDFG"),new Address("SDFEDF","SDS","DFD","DFSD"));
          map.put(new Customer(1235,"ram","34545","DFDFG"),new Address("2313F","SDS","DFD","DFSD"));
          map.put(new Customer(1236,"ram","34545","DFDFG"),new Address("2313F","SDS","DFD","DFSD")); 
          map.put(new Customer(1233,"moulya","34545","DFDFG"),new Address("SDFEDF","SDS","DFD","DFSD"));
	
      	Set<Customer> k= map.keySet();
		Iterator<Customer> it=k.iterator();
		 while(it.hasNext())
		    {
		    	Customer key=it.next();
		    	System.out.println(key+"--->"+map.get(key));
		    	
		    }
	
	}
	

}
