package com.capgemini;

public class Customer implements Comparable<Customer> {
private int customerId;
private String customerName;
private String email;
private String mobileNo;
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email + ", mobileNo="
			+ mobileNo + "]";
}
public Customer() {
	
}
public Customer(int customerId, String customerName, String email, String mobileNo) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.email = email;
	this.mobileNo = mobileNo;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + customerId;
	result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (customerId != other.customerId)
		return false;
	if (customerName == null) {
		if (other.customerName != null)
			return false;
	} else if (!customerName.equals(other.customerName))
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (mobileNo == null) {
		if (other.mobileNo != null)
			return false;
	} else if (!mobileNo.equals(other.mobileNo))
		return false;
	return true;
}
@Override
public int compareTo(Customer o) {

	if(this.getCustomerId()>o.getCustomerId())
		return 1;
	else if(this.getCustomerId()<o.getCustomerId())
		return -1;
	else
	    return 0;
	
}


}
