package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webdriver;
	private WebElement webelement, element;
	private String message;

	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\mokotha\\Downloads\\chromedriver.exe");
		webdriver = new ChromeDriver();
	}

	@Given("^Open ConferenceRegistartion\\.html page$")
	public void open_ConferenceRegistartion_html_page() throws Throwable {
		webdriver.get("file:///D:/Users/mokotha/Desktop/Conferencebooking/ConferenceRegistartion.html");
	}

	@Given("^provide correct details$")
	public void provide_correct_details() throws Throwable {
		// 3. page name
		if (!webdriver.getTitle().startsWith("Conference Registartion")) {
			webdriver.quit();
		}
		sleepForSomeTime();

		// 4. heading
		webelement = webdriver.findElement(By.xpath("/html/body/h4"));
		if (!webelement.getText().equals("Step 1: Personal Details")) {
			webdriver.quit();
		}
		sleepForSomeTime();

		// 5. first name
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the First Name");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		element = webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("Moulya");

		// 6. last name
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Last Name");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		element = webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("Kotha");

		// 7. email
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Email");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		element = webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("mou@gmail.com");

		// 8. contact no
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Contact No.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		element = webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("5987654321");

		// 9. correct phone number
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please enter valid Contact no.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).clear();
		webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("9638285683");

		// 10. number of people
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Please fill the Number of people attending");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select/option[2]"));
		System.out.println((element.isDisplayed()));
		element.click();

		// 11. street address
		element = webdriver.findElement(By.xpath("//*[@id=\"txtAddress1\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("Central");
		element = webdriver.findElement(By.xpath("//*[@id=\"txtAddress2\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("Central Avenue");
		sleepForSomeTime();

		// 12. city
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select/option[4]"));
		System.out.println((element.isDisplayed()));
		element.click();
		sleepForSomeTime();

		// 13. state
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select/option[4]"));
		System.out.println((element.isDisplayed()));
		element.click();
		sleepForSomeTime();

		// 14. Conference full-Access(member)
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
		System.out.println((element.isDisplayed()));
		element.click();
		sleepForSomeTime();

		// 15. Conference full-Access(non-member)
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
		System.out.println((element.isDisplayed()));
		element.click();
		sleepForSomeTime();

	}

	@When("^click next link$")
	public void click_next_link() throws Throwable {
		// 16. next
		element = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();

		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Personal details are validated.");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();
	}

	@Then("^navigate to PaymentDetails\\.html$")
	public void navigate_to_PaymentDetails_html() throws Throwable {
		// 16. next
		message = webdriver.getCurrentUrl();
		assertEquals(message, "file:///D:/Users/mokotha/Desktop/Conferencebooking/PaymentDetails.html");
		sleepForSomeTime();

		webdriver.quit();
	}

	@Given("^Open PaymentDetails\\.html page$")
	public void open_PaymentDetails_html_page() throws Throwable {
		// 16. next
		webdriver.get("file:///D:/Users/mokotha/Desktop/Conferencebooking/PaymentDetails.html");
		
		//message = webdriver.getCurrentUrl();
		//assertEquals(message, "file:///D:/Users/ketchauh/Downloads/Conferencebooking/PaymentDetails.html");
	}

	@Given("^correct details provided$")
	public void correct_details_provided() throws Throwable {
		// 17. first name
		// 18. last name
		element = webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("Moulya Kotha");
		sleepForSomeTime();

		// 19. card number
		element = webdriver.findElement(By.xpath("//*[@id=\"txtDebit\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("7895632589657412");
		sleepForSomeTime();

		// 20. cvv
		element = webdriver.findElement(By.xpath("//*[@id=\"txtCvv\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("040");
		sleepForSomeTime();

		// 21. Expiration Month
		element = webdriver.findElement(By.xpath("//*[@id=\"txtMonth\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("08");
		sleepForSomeTime();

		// 22. Expiration Year
		element = webdriver.findElement(By.xpath("//*[@id=\"txtYear\"]"));
		System.out.println((element.isDisplayed()));
		element.sendKeys("2023");
		sleepForSomeTime();

	}

	@When("^click on Make Payment button$")
	public void click_on_Make_Payment_button() throws Throwable {
		// 23. register
		element = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		element.click();
	}

	@Then("^show successful message$")
	public void show_successful_message() throws Throwable {
		// 23. register
		message = webdriver.switchTo().alert().getText();
		assertEquals(message, "Conference Room Booking successfully done!!!");
		sleepForSomeTime();
		webdriver.switchTo().alert().accept();

		webdriver.quit();
	}
	
	private void sleepForSomeTime() {
		/*try {
			(new WebDriverWait(webdriver,2)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver d) {
					return false;
				}
			});
		} catch (Exception e) {
			// TODO: handle exception
		}*/
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
