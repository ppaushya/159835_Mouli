import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { MerchantComponent } from './merchant/merchant.component';
import { ProductsComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { PromosComponent } from './promos/promos.component';
import { GenerateCouponsComponent } from './generate-coupons/generate-coupons.component';
import { BusinessAnalysisComponent } from './business-analysis/business-analysis.component';
import { MerchantService } from './merchant-service.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { UploadImagesComponent } from './upload-images/upload-images.component';
import { UploadFileService } from './upload-file.service';

@NgModule({
  declarations: [
    AppComponent,
    AdminMainPageComponent,
    MerchantComponent,
    ProductsComponent,
    CustomersComponent,
    PromosComponent,
    GenerateCouponsComponent,
    BusinessAnalysisComponent,
    UploadImagesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule
  ],
  providers: [MerchantService,UploadFileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
