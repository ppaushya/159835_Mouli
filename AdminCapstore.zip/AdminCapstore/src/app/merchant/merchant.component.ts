import { Component, OnInit } from '@angular/core';
import { Merchant } from '../merchant';
import { MerchantService } from '../merchant-service.service';
import {trigger,style,transition,animate,keyframes,query,stagger} from '@angular/animations';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css'],
  animations:[
    trigger('ml',[
                   transition('* => *',
                        [
                          query(':enter',style({opacity:0}),{optional:true}),

                          query(':enter',stagger('300ms',[

                            animate('.6s ease-in', keyframes([
                              style({opacity:0, transform:'translateY(-75%)',offset:0}),
                              style({opacity:0.5, transform:'translateY(35px)',offset:.3}),
                              style({opacity:1, transform:'translateY(0)',offset:1})
                            ]))]), {optional:true}),

                          query(':leave',stagger('300ms',[

                            animate('.6s ease-in', keyframes([
                               style({opacity:1, transform:'translateY(0)',offset:0}),
                               style({opacity:0.5, transform:'translateY(35px)',offset:.3}),
                               style({opacity:0, transform:'translateY(-75%)',offset:1})
                            ]))]), {optional:true}),

                        ])

                ])

           ]
})
export class MerchantComponent implements OnInit {
     merchants:Merchant[];
   

  constructor(private  merchantService:MerchantService ) { }

  ngOnInit() {
    this.getMerchants();
    
  }

  getMerchants(): void{
    this.merchantService.getMerchants().subscribe(merchants=>this.merchants=merchants);
 
 }

 deleteMerchant(merchantId):void{
  console.log("delete");
  this.merchantService.deleteMerchant(merchantId).
  subscribe(merchants => console.log(merchants));
  window.location.reload();
}

dltMerchant(merchantId:any)
{
console.log("this MERCHANT id is "+merchantId); 
this.deleteMerchant(merchantId);

}  


verifyMerchant(merchant:Merchant) : void{

this.merchantService.verifyMerchant(merchant).subscribe(merchants => this.merchants = merchants);
// window.location.reload();

}
 

}
