import { Component, OnInit } from '@angular/core';
import { Inventory } from '../Inventory';
import { ProductService } from '../product-service.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  inventories: Inventory[] = [];

  inventory: Inventory=new Inventory();

  _listFilter: string;

  filteredInventories: Inventory[];

  constructor(private productService: ProductService) {


    this.listFilter = '';

  }

  get listFilter(): string {

    return this._listFilter;

  }



  set listFilter(value: string) {

    this._listFilter = value;

    this.filteredInventories = this.listFilter ? this.performFilter(this.listFilter) : this.inventories;

  }

  ngOnInit() {
    
    this.getInventories();
  }


  getInventories():void{

    this.productService.getInventories().subscribe(inventories => {this.inventories=inventories;
      this.filteredInventories=this.inventories;}); 

  }


  deleteInventory(inventoryId: number) {
  
    this.productService.deleteInventory(inventoryId).subscribe(inventories => this.inventories = inventories);
  }

  

  editInventory(inventory:Inventory){
    this.productService.editInventory(inventory).subscribe(inventory => this.inventories = inventory);
  }



  performFilter(filterBy: string): Inventory[] {

    filterBy = filterBy.toLocaleLowerCase();

    return this.inventories.filter((inventory: Inventory) =>

    inventory.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);

  }


}
