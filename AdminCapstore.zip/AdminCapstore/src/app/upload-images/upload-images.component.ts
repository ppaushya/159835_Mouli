import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { UploadFileService } from '../upload-file.service';

@Component({
  selector: 'app-upload-images',
  templateUrl: './upload-images.component.html',
  styleUrls: ['./upload-images.component.css']
})
export class UploadImagesComponent implements OnInit {

  products: Product[] = [
    {
    "productId":100,
    "productName":"Redmi 4",
    "productCategory":"Electronics",
    "inventory":null,
    "promo":null,
    "productPrice":1000,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"smarter then Iphone",
    "quantity":200,
    "discount":10,
    "brand":"Xiaomi"
  },
  {
    "productId":101,
    "productName":"Redmi 5",
    "productCategory":"Electronics",
    "inventory":null,
    "promo":null,
    "productPrice":10000,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"poor's Iphone",
    "quantity":200,
    "discount":10,
    "brand":"Xiaomi"
  },
  {
    "productId":102,
    "productName":"Samsung Galaxy",
    "productCategory":"Electronics",
    "inventory":null,
    "promo":null,
    "productPrice":1000,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"china product",
    "quantity":200,
    "discount":10,
    "brand":"samsung"
  },
  {
    "productId":103,
    "productName":"Sweat Shirt",
    "productCategory":"Clothing",
    "inventory":null,
    "promo":null,
    "productPrice":500,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"so light",
    "quantity":200,
    "discount":10,
    "brand":"Levis"
  },
  {
    "productId":104,
    "productName":"Wheat",
    "productCategory":"Grocery",
    "inventory":null,
    "promo":null,
    "productPrice":100,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"eat and chill",
    "quantity":200,
    "discount":10,
    "brand":"Aashirvaadh"
  },
  {
    "productId":105,
    "productName":"Pilgrimage ",
    "productCategory":"Book",
    "inventory":null,
    "promo":null,
    "productPrice":700,
    "productsSold":2,
    "productView":2,
    "isPromotionMessageSent":true,
    "productDescription":"by Paul Cohelo",
    "quantity":200,
    "discount":10,
    "brand":"Something Publishers"
  }

];

  product: Product=new Product();

  _listFilter: string;

  filteredProducts: Product[];


  get listFilter(): string {

    return this._listFilter;

  }



  set listFilter(value: string) {

    this._listFilter = value;

    this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;

  }

  ngOnInit() {
    
    this.getInventories();
  }



  selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };

  constructor(private uploadService: UploadFileService) { 
    this.listFilter = '';
  }

  

  selectFile(event) {
    const file = event.target.files.item(0);

    if (file.type.match('image.*')) {
      this.selectedFiles = event.target.files;
    } else {
      alert('invalid format!');
    }
  }

  upload(productId:number) {
    this.progress.percentage = 0;

    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStorage(this.currentFileUpload,productId).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
        alert("File is completely uploaded!");
      }
    });

    this.selectedFiles = undefined;
  }



  getInventories():void{

    // this.productService.getInventories().subscribe(inventories => {this.inventories=inventories;
    //   this.filteredInventories=this.inventories;}); 

  }





  performFilter(filterBy: string): Product[] {

    filterBy = filterBy.toLocaleLowerCase();

    return this.products.filter((product: Product) =>

    product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1 ||
    product.productCategory.toLocaleLowerCase().indexOf(filterBy) !== -1 || 
    product.brand.toLocaleLowerCase().indexOf(filterBy) !== -1);

  }


}
