package org.capgemini.demo;

public interface InnerInterface {
	void draw();
	public interface Inner1
	{
		void fillColor();
	}


}
