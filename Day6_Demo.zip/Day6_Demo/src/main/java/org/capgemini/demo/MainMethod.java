package org.capgemini.demo;

public class MainMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass outer=new OuterClass();
		outer.details();
		
	}

}
