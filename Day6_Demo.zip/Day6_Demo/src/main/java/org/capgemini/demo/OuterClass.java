package org.capgemini.demo;

public class OuterClass {
	String name="JERRY";
	public void details() {
		int count=100;
		//Method Local INner Classes
		class InnerClass{
			int num=45;
			String name="Jack";
			public void print() {
				OuterClass obj=new OuterClass();
				
				System.out.println("Num:"+num);
				System.out.println("Name:"+name);
				System.out.println("Name:"+obj.name);


			}
		}
		InnerClass in=new InnerClass();
		in.print();
	}

}
