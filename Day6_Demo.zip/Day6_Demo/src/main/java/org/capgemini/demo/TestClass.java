package org.capgemini.demo;

import org.capgemini.demo.InnerInterface.Inner1;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
InnerInterface inn= new MyClass();
inn.draw();
InnerInterface .Inner1 in1= InnerInterface.Inner1. new MyClass();
in1.fillColor();
	}

}
