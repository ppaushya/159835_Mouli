package org.capgemini.demo;

public class MyClass implements InnerInterface,Inner1 {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

}
