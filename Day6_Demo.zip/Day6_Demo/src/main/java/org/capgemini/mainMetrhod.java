package org.capgemini;

public class mainMetrhod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticNest.Inner.show();
		StaticNest.Inner obj=new StaticNest.Inner();
		obj.print();
	}

}
