package org.capgemini;

public class StaticNest {
	int count=100;
	static float pi=3.14f;
	
	public static class Inner{
		int num=50;
		public void print() {
			System.out.println("Num"+num);
			//System.out.println("Count"+count);
			System.out.println("Pi"+pi);
			show();

		}
		public static void show()
		{
			System.out.println("Show Meethod is in inner class");
		}
	}
	public static void show()
	{
		System.out.println("Show Meethod is in outer class");
	}

}
