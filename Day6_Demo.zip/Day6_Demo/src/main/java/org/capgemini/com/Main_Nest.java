package org.capgemini.com;

public class Main_Nest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//NestedDemo obj=new NestedDemo();
		//NestedDemo.InnerClass=new obj.InnerClass();
		NestedDemo.InnerClass inn=new NestedDemo().new InnerClass();
		inn.show();

	}

}
