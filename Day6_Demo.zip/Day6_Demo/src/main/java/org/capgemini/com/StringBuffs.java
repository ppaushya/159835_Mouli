package org.capgemini.com;

public class StringBuffs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//StringBuffer buffer=new StringBuffer("Tom");
		StringBuilder buffer=new StringBuilder(50);
System.out.println(buffer);
System.out.println(buffer.length());
System.out.println(buffer.capacity());
buffer.append("jerry");
System.out.println(buffer);
System.out.println(buffer.length());
System.out.println(buffer.capacity());
buffer.insert(0, "Moulya");
System.out.println(buffer);
buffer.replace(0, 3, "Venkata");
System.out.println(buffer);
buffer.delete(3, 5);
System.out.println(buffer);
buffer.ensureCapacity(201);
System.out.println(buffer);
System.out.println(buffer.capacity());

	}

}
