package org.capgemini.com;
import java.util.Calendar;
import java.util.GregorianCalendar;//Concrete class
import java.util.Date;
public class CalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Calendar c=new Calendar();as Calendar is an abstract class
		Calendar c=new GregorianCalendar();
		System.out.println(c);
		System.out.println(c.get(Calendar.DAY_OF_YEAR));
		System.out.println(c.get(Calendar.DAY_OF_MONTH));
		 Calendar today=Calendar.getInstance();
		 System.out.println(today);
		 today.add(Calendar.YEAR,6);
		 System.out.println();
		 System.out.println(today);
		 System.out.println(c.getMaximum(Calendar.YEAR));
		 System.out.println(c.getMinimum(Calendar.YEAR));
		 System.out.println(c.getMinimum(Calendar.MONTH));
		 System.out.println(c.getMaximum(Calendar.MONTH));
		 System.out.println(c.getMaximum(Calendar.DAY_OF_MONTH));
		 System.out.println(today.getTime());//converts into date object

	}

}
