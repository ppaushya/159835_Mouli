package org.capgemini.com;
import static org.capgemini.StaticNest.Inner.*;//allows static properties

import org.capgemini.StaticNest.Inner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
show();
Inner.show();
Inner obj=new Inner();
obj.print();

	}

}
