package org.capgemini.com;

public class NestedDemo {

	
int num;
String name;
         class InnerClass
         {
        	
        	 String address;
        	 public void show()
        	 {
        		 System.out.println(num);
        		 System.out.println(name);
        		 System.out.println(address);

        	 }
         }
	public void print()
	{
		InnerClass obj=new InnerClass();
		System.out.println(obj.address);
	}

}
