package org.capgemini.com;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.Locale;

public class NewDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instant i=Instant.now();
		System.out.println(Instant.now());
		System.out.println(Instant.MIN);
		System.out.println(Instant.MAX);
		//System.out.println(i.MIN);
		LocalDate local=LocalDate.now();
		LocalDate l2=LocalDate.of(2001,05,13);
		System.out.println(local);
		LocalTime localTime=LocalTime.now();
		System.out.println(localTime);
		Period period=Period.between(l2,local);
		System.out.println(period.getMonths());
		System.out.println(period.getYears());
		System.out.println(period.getDays());
		System.out.println(period.isNegative());
	LocalDate nextSunday=local.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
	LocalDate next=local.with(TemporalAdjusters.previous(DayOfWeek.SUNDAY));

	System.out.println(nextSunday);
	System.out.println(next);
System.out.println(localTime);
LocalTime zoneTime=LocalTime.ofInstant(Instant.now(),ZoneId.of("Europe/London"));
System.out.println("zONEtIME"+zoneTime);
ZonedDateTime meeting=ZonedDateTime.of(LocalDate.of(2018, 11, 23),LocalTime.of(13,30),ZoneId.of("Europe/London"));
//Duration.between();
System.out.println(meeting.toInstant());
DateFormat format=DateFormat.getDateInstance(2);
DateFormat format1=DateFormat.getDateInstance(3,Locale.getDefault());

System.out.println(format.format(new Date()));
System.out.println(format1.format(new Date()));
//CONVERT OLD VERSION TO NEW DATE VERSION
//Instant to Date
Date date=Date.from(i);
System.out.println(date);
//Date to instant
Instant instant=date.toInstant();
System.out.println(instant);
//Instant to timestamp
Timestamp time=Timestamp.from(instant);
System.out.println(time);
//TimeStamp to instant
Instant instant1=time.toInstant();
System.out.println(instant1);





	}

}
