package org.capgemini.com;

public class WrappDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Integer integer=new Integer(58);
       int mynum=200;
       //Primitive to object(Autoboxing)
       integer=mynum;
       System.out.println(integer);
       System.out.println(Integer.MAX_VALUE);
       System.out.println(Integer.MIN_VALUE);
       System.out.println(Double.MIN_NORMAL);
       System.out.println(Double.MIN_EXPONENT);
       System.out.println(Double.MAX_EXPONENT);
//Double value=mynum.doubleValue();
       String str="23";
       int num=Integer.parseInt(str);
       System.out.println(num);

	}

}
