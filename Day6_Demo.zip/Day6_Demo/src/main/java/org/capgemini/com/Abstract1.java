package org.capgemini.com;

public class Abstract1 {

}
