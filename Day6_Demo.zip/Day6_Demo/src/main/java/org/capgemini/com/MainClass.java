package org.capgemini.com;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer num=100;
Integer mynum=new Integer(100);
Integer value=100;
Integer myvalue=new Integer(100);
System.out.println(num.equals(mynum));
System.out.println(num==(mynum));//compares Memory
System.out.println(num.equals(value));
System.out.println(num==value);
System.out.println(num.equals(myvalue));
System.out.println(num==myvalue);
System.out.println(mynum==myvalue);
System.out.println(mynum.equals(myvalue));



	}

}
