package org.capgemini.com;
import java.util.Date;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Date d=new Date();
     System.out.println(d);
     Date d1=new Date(2018-1900,05,13);
     System.out.println(d1);
     //System.out.println(d1-d);
     System.out.println(d1.getTime());
     System.out.println(d.getTime());
Date d2=new Date(d.getTime());
System.out.println(d2);
Date d3=new Date(1528828200000l);
System.out.println(d3);
System.out.println(d.getDate());
System.out.println(d.before(d1));
System.out.println(d.after(d1));
System.out.println(d.getDay());
System.out.println(d.getHours());
System.out.println(d.getMinutes());
System.out.println(d.getSeconds());
System.out.println(d.getYear()+1900);
d.setTime(1528828200000l);
System.out.println(d);
d.setDate(20);
System.out.println(d);
d.setHours(18);
System.out.println(d);
d.setMonth(9);
System.out.println(d);
d.setYear(2017-1900);
System.out.println(d);
d.setMinutes(62);
System.out.println(d);
d.setSeconds(62);
System.out.println(d);
















	}

}
