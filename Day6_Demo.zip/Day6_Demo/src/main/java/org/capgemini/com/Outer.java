package org.capgemini.com;

public abstract class Outer {
	int num=100;
	public void detail() {
		public abstract class molya{
			
		}
	}

}
