package org.capgemini;

public abstract class AbstractClass {
  abstract void print();
  public void nonAbstract() {
	  System.out.println("NON Abstract Method");
  }
}
