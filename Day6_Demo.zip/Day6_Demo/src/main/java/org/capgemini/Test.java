package org.capgemini;

public class Test extends AbstractClass{

	@Override
	void print() {
		// TODO Auto-generated method stub
		System.out.println("Child class print Method");
	}

}
