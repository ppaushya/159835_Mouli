package org.capgemini;

public class Main_NestedInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractClass obj=new AbstractClass()
				{

					@Override
					void print() {
						// TODO Auto-generated method stub
						System.out.println("Anonymous class");
					}
					 public void nonAbstract() {
						  System.out.println("Anonymous_NON Abstract Method");
					  }
				};
				AbstractClass obj1=new AbstractClass()
				{

					@Override
					void print() {
						// TODO Auto-generated method stub
						System.out.println("anony 2 class");
					}
			
				};
				
				obj1.print();
				obj.print();
				obj.nonAbstract();
				

	}

}
