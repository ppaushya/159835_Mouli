package org.cap;

public class Child extends Parent {
	public Child()
	{
		System.out.println("Child constuctor");
	}
	public void show()
	 {
		 System.out.println(num);
	 }

}
