package org.cap;

public class Parent extends GrandParent {
	public Parent()
	{
		System.out.println("Parent constuctor");
	}
 public void show()
 {
	 System.out.println(num);
 }
 public void calculate()
 {
	 System.out.println("Calculate Parent class");
 }
}
