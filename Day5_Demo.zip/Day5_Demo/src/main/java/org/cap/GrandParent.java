package org.cap;

public class GrandParent {
	 protected int num=1990;
	 public GrandParent()
		{
			System.out.println("GrandParent constuctor");
		}
	 public void show()
	 {
		 System.out.println(num);
	 }
}
