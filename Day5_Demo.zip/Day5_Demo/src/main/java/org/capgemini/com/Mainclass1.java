package org.capgemini.com;

public class Mainclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
   DailyWorker d=new DailyWorker();
   d.ComPay(456);
   SalariedWorker s=new SalariedWorker();
   s.ComPay(20);
	}

}
