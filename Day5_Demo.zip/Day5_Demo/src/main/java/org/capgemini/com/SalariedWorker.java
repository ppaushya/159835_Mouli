package org.capgemini.com;

public class SalariedWorker extends Worker {
	
	@Override
	public void ComPay(int hours) {
		// TODO Auto-generated method stub
		 System.out.println("Salary of a salaried  worker"+salary*40);

	}

}
