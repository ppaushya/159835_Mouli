package org.capgemini.com;
import java.util.Scanner;
public class Employee extends Person {
	double salary;
	boolean isPermanent;
	
	public Employee() {
		
	}
	public Employee(int personId, String firstName, String lastName,double salary, boolean isPermanent) {
		this(salary,isPermanent);
		//super(personId,firstName,lastName);
		//this.salary = salary;
		//this.isPermanent = isPermanent;
		
	}
	public Employee(double salary, boolean isPermanent) {
		this.salary = salary;
		this.isPermanent = isPermanent;
	}
	public void getEmployee()
	{
		Scanner scan= new Scanner(System.in);
		getPerson();
		 	
		 System.out.println("Enter salary");
		 salary=scan.nextDouble();
		 System.out.println("Enter the status[true/false]");
		 isPermanent=scan.nextBoolean();
	}
 public void showEmployee()
 {
	 //showPerson();
	 System.out.println(personId+", "+firstName+", "+lastName);
	 System.out.println(salary+", "+isPermanent);
 }
 @Override

 public void show()
 {
	 super.show();
	 System.out.println("Employee class ---->show method");
 }
 
}
