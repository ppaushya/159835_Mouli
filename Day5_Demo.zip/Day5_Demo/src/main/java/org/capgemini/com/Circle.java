package org.capgemini.com;

public class Circle extends Shape {

	float r=2,pi=3.14f;
	public Circle()
	{super(100,100);
		System.out.println("Circle Default constuctor");
	}
	public Circle(float radius)
	{super(100,100);
		this.r=radius;
		System.out.println("Argument constuctor of circle class");

	}
	public float calculateArea()
	{
		return pi*r*r;
	}
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Circle class draw method!");
	}

}
