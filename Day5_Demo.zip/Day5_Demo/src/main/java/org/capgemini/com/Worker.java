package org.capgemini.com;

public abstract class Worker {
	String name;
	double salary=50000;
	public abstract void ComPay(int hours);

}
