package org.capgemini.com;

public class Mclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Shape s=new Shape();
Circle c=new Circle();
Circle c1=new Circle(2.45f);
float area=c.calculateArea();
System.out.println("Area is"+area);
c.draw();
c1.draw();
}

}
