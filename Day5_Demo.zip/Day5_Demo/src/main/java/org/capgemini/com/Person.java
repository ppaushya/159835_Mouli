package org.capgemini.com;
import java.util.Scanner;
public class Person {
 int personId;
 protected String firstName;
  String lastName;

  public Person(){
	  
  }
 public Person(int personId, String firstName, String lastName) {
	
	this.personId = personId;
	this.firstName = firstName;
	this.lastName = lastName;
}
 
 public void getPerson() {
	 Scanner scan= new Scanner(System.in);
	 System.out.println("Enter personId");
	 personId=scan.nextInt();
	 System.out.println("Enter Firstname");
	 firstName=scan.next();
	 System.out.println("Enter lastname");
	 lastName=scan.next();
	 
 }
 public void showPerson()
 {
	 System.out.println(personId+", "+firstName+", "+lastName);
 }
 
public void show()
{
	System.out.println("Person class ---->show method");
}
}
