package org.capgemini.com;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lighting l=new Lighting();
		l.calculateCharges();
		Ordinary o=new Ordinary();
		o.calculateCharges();
		Urgent u=new Urgent();
		u.calculateCharges();
	}

}
