package org.capgemini.com;

public class DailyWorker extends Worker{

	@Override
	public void ComPay(int hours) {
		
	 System.out.println("Salary of an daily worker"+salary*hours/7);
	}

}
