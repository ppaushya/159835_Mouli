package org.capgemini.com;

public class Lighting extends TrunkCall{

	@Override
	public void calculateCharges() {
		// TODO Auto-generated method stub
		System.out.println("Charge for Lighting call"+duration*100);
	}

}
