package org.capgemini.com;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			 //Employee emp=new Person();
		Employee emp=new Employee();
			 Employee emp1=new Employee(2000,false);
			 Employee emp2=new Employee(221,"Trr","FF",5423,false);
			 emp2.showEmployee();
			 emp1.showEmployee();
			 
			// Person person= new Employee();//memory reservatiion for both but reference is for parent
			//person.show();
			Person p=new Person();
			p.show();
	//emp.show();
			/*// emp.getPerson();
			 emp.getEmployee();
			// emp.showPerson();
			 emp.showEmployee();*/
		 
	}

}
