package org.capgemini.com;

public abstract class   Shape {
	int width;
	int height;
	public Shape() {
		System.out.println("Default constuctor of Shape class");
	}
	public Shape(int w,int h) {
		this.width=w;this.height=h;
		System.out.println("Argument constuctor of Shape class");
	}
	public void info() {
		System.out.println("Shape information");
	}

	public abstract void draw();
}
