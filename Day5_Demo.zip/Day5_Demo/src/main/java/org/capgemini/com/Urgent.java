package org.capgemini.com;

public class Urgent extends TrunkCall{

	@Override
	public void calculateCharges() {
		// TODO Auto-generated method stub
		System.out.println("Charge for Urgent call"+duration*50);
	}

}
