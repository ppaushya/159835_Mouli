package org.capgemini.com;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student=new Student();
		student.setStudentId(10001);
		student.setFirstName("Moulya");
		student.setLastName("Kotha");
		student.setRegFees(50000);
		System.out.println(student.getStudentId()+"- "+student.getFirstName()+"- "+student.getLastName()+"- "+student.getRegFees());

	}

}
