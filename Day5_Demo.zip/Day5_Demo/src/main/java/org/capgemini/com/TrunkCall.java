package org.capgemini.com;

public abstract class TrunkCall {
	double duration=60;
	public abstract void calculateCharges();
	
}
