package org.capgemini.com;

public class Ordinary extends TrunkCall {

	@Override
	public void calculateCharges() {
		System.out.println("Charge for Ordinary call"+duration*10);
		
	}

}
