package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c=new Circle();
		c.draw();
		c.info();
		c.calculateArea();
		Shape c1=new Circle();
		///c1.draw();
		//c1.info();
		//c1.calculateArea();
		Shape.show();
		c.shapePoints();
		//c.details();
		
	}

}
