package org.capgemini.demo;

public class Circle implements Shape,Color {

	@Override
	public void draw() {
		//details();
		shapePoints();
		System.out.println("Circle class draw method");
		
	}

	@Override
	public void info() {
		// TODO Auto-generated method stub
		Shape.show();
		System.out.println("Circle class info method");

	}
	public void calculateArea() {
		System.out.println("Circle class area method");

	}
	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shapePoints() {
		// TODO Auto-generated method stub
		//Shape.super.shapePoints();
		
	}

}
