package org.capgemini.demo;

public interface Shape {
	int num=100;
	public static final int d=100;
	  final static public  int c=100;
	public abstract void draw();
	void info();
	public static void show()
	{
		details();
System.out.println("Static method in Shape");
	}
	default void shapePoints() {
		details();
		System.out.println("Shape points method in Shape");
	}
private static void details()
{
	System.out.println("Shape inteface details method");
}
	
	

}
