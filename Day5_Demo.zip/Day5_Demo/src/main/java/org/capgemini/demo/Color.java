package org.capgemini.demo;

public interface Color {
	void fillColor();
	default void shapePoints()
	{
		System.out.println("Static method in Shape");
	}
}
