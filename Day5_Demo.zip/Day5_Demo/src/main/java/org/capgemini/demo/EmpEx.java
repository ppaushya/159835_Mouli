package org.capgemini.demo;
import org.capgemini.com.Person;
public class EmpEx extends Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmpEx emp=new EmpEx();
		System.out.println(emp.firstName);
	}

}
