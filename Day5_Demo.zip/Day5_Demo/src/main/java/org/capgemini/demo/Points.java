package org.capgemini.demo;

public interface  Points extends Shape,Color {

	public void getPoints();

	@Override
	default void shapePoints() {
		// TODO Auto-generated method stub
		Color.super.shapePoints();
	}
}
