package org.capgemini.demo;

public class Triangle implements Shape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info() {
		// TODO Auto-generated method stub
		
	}

}
