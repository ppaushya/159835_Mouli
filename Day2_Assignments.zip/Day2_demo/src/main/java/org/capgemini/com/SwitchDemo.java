package org.capgemini.com;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		char a='b';
		String str="moulya";
		short b=104;
		//enum arr{1,2,3};
		switch(num)
		{
		case 1:
		case 100:
			System.out.println("One");
			System.out.println("Block");
			break;
		case 2:
			System.out.println("Two");
			break;
		case 10:
			System.out.println("ten");
			//break;
			default:
				System.out.println("default block");

			//	break;
		}
		switch(a) {
		case 'a':
			System.out.println("a");
			break;
		case 'b':
			System.out.println("b");
			break;
		default:
			System.out.println("One");
			break;
		}
		switch(str)
		{
		case "one":
			System.out.println("one");
			break;
		case "moulya":
			System.out.println("Moulya");
  break;
		}
		switch(b)
		{
		case 102:
			System.out.println("wew");
			break;
			default:
				System.out.println("Ejsdh");
				break;

		}
	}

}
