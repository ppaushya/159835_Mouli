package org.capgemini.com;
import java.util.*;
public class Patterns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    for(int i=5;i>0;i--)
    {
    	for(int j=4;j>0;j--)
    	{
    		if(j>=i)
    			 System.out.print("\t");
    		
    		else
    			System.out.print("*\t");
    	}
    	 System.out.println();
    }
   //
    int c=1;
    for(int i=0;i<5;i++)
    {
    	for(int j=0;j<i;j++)
    	{
    		 System.out.print(c+"\t");
    		 c++;
    	}
    	
    	 System.out.println();
    
    }
    Scanner scan =new Scanner(System.in);
    int n=scan.nextInt();
    int count=1;
    for(int i=0;i<n;i++)
    {
    	
    	for(int s=0;s<n-1;s++)
    		{
    		System.out.print(" ");
    		}
    	for(int j=0;j<=i;j++)
    	{
    		
    		if(j==0||i==0)
    		{
    			
    		count=1;
    		}
    		else
    			count=count*(i-j+1)/j;
    		System.out.print(count+"  ");
    	}
    	
    	System.out.println();
    }
	}

}
