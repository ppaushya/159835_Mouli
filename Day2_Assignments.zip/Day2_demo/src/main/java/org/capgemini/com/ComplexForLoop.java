package org.capgemini.com;

public class ComplexForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		for(i=1,j=10;i<=10&&j>1;i++,j--)//;
		{
			System.out.println(i+"--->"+j);
		}
	}

}
