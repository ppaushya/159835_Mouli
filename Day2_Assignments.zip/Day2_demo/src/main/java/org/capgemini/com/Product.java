package org.capgemini.com;
import java.util.*;
public class Product {
	String productName;
	int productId;
	int quantity;
	float price;
    float discount;
    float tax;
    
    public void getProductDetails()
    {
    	System.out.println("Enter the details of a product");
    	Scanner scan=new Scanner(System.in);
    	productName=scan.next();
    	productId=scan.nextInt();
    	quantity=scan.nextInt();
    	price=scan.nextFloat();
    	discount=scan.nextFloat();
    	
    }
   
    public void calculateTax()
    {
    	if(discount>90)
    	{
    		tax=quantity*price*0.01f;
    	}
    	else   if(discount>80 && discount<=90)
    	{
    		tax=quantity*price*0.12f;
    	}
    	else if(discount>60 && discount<=80)
    	{
    		tax=quantity*price*0.2f;

    	}
    	else if(discount>50 && discount<=60)
    	{
    		tax=quantity*price*0.25f;

    	}
    	else 
    	{
    		tax=quantity*price*0.4f;

    	}
    }
    public void calculateDiscount()
    {
    	 discount=quantity*price*discount/100;
    	System.out.println("Discount :"+discount);
    }
    public void calculateFinalPrice()
    {
    	price=quantity* price+tax-discount;
    	System.out.println("Total Price :"+price);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan1=new Scanner(System.in);
		String choice;
		do{
			
			
		
			Product p=new Product();
		   p.getProductDetails();
		   p.calculateTax();
		   p.calculateDiscount();
		   p.calculateFinalPrice();
		   System.out.println("Do you wish to continue? [Y|N]");
		    choice=scan1.next();
		   
	}while(choice.charAt(0)=='y' ||choice.charAt(0)=='Y');

}
}