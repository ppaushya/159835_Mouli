package org.capgemini.com;

public class EvenNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i,sum=0,count=0,temp=0,j;
		   System.out.println("Even numbers  between 1 to 100");
			for(i=2;i<=100;)
			{
				if(count==5)
				{
					count=0;
				}
				
				for(j=0;j<5;j++)
				{
					if(count==j)
					{
						System.out.print(i+" ");
					
					}
					else
					{
						System.out.print("* ");
					}
				   i+=2;
				   sum=sum+i;
				}
			   System.out.println();
				
				count++;
			}

		System.out.println("Sum is"+sum);
           
	}

}
