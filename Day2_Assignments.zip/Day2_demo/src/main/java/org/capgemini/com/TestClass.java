package org.capgemini.com;

public class TestClass {

	 public void testIf(int num) {
		 if(num>0)
		 {
			 System.out.println("Hey the number is:");
			 System.out.println("Positive");
			 if(num%2==0)
			 {
				 System.out.println("Even Number");

			 }
			 else
				 System.out.println("Odd Number");

		 }
		 else if(num<0) {
			 System.out.println("Hey the number is:");
			 System.out.println("Negative");
		 }
		 else
		 {
			 System.out.println("Hey the number is :");
			 System.out.println("Zero");
		 }
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestClass class1=new TestClass();
		class1.testIf(48);
		class1.testIf(-32);
		class1.testIf(0);

	}

}
