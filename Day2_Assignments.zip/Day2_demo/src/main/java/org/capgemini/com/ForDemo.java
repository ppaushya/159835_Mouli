package org.capgemini.com;

public class ForDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		for(i=1;;i++)
		{
			System.out.println(i);
			if(i==10)
				break;
		}

}
}
