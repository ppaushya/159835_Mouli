package org.capgemini.com;
import java.util.*;

public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a number ");
	int n=scan.nextInt();
	int sum=0;
	while(n>0) {
	sum=sum+n%10;
		
		n=n/10;

	}
	System.out.println("Sum of the digits is: "+sum);
	}

}
