package org.capgemini.com;

import java.util.Scanner;

public class Que4 {
	
	String str="";
	char[] mystr= new char[str.length()];
	
	public void LetterChanges(String str)
	{
		mystr= str.toCharArray();
		for(int i=0;i<str.length();i++)
		{
			if(mystr[i]=='z')
				mystr[i]='a';
			else if(mystr[i]==' ')
				mystr[i]=' ';
			else
				mystr[i]=(char)(mystr[i]+1);
		}
		for(int i=0;i<str.length();i++)
		{
			if(mystr[i]=='a'||mystr[i]=='e'||mystr[i]=='i'||mystr[i]=='o'||mystr[i]=='u')
				mystr[i]=(char)(mystr[i]-32);
			System.out.print(mystr[i]);
		}

	}
	

	public static void main(String[] args) {
	

		Que4 q=new Que4();
		Scanner s= new Scanner(System.in);
		System.out.println("enter string");

		q.str=s.nextLine();
		q.LetterChanges(q.str);
		s.close();

	}

}
