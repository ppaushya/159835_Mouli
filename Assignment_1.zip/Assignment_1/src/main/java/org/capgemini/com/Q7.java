package org.capgemini.com;
import java.util.*;

public class Q7 {

	public static void main(String[] args) {
		Scanner s1=new Scanner(System.in);
		System.out.println("Enter a number");
		int n=s1.nextInt();
		for(int i=0;i<n;i++)
		{
			
		}
		

	}

}
