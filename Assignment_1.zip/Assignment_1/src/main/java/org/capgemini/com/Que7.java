package org.capgemini.com;

import java.util.Scanner;

public class Que7 {
	String str="";
	
	public void longestWord(String str)
	{
		
	}

	public static void main(String[] args) {
		
		Que7 q=new Que7();
		Scanner s= new Scanner(System.in);
		System.out.println("enter string");

		q.str=s.nextLine();
		q.longestWord(q.str);
		s.close();

	}

}
