package org.capgemini.com;

import java.util.Scanner;

public class Que3 {
	String str="",newstr="",out="";
	char[] mystr=new char[str.length()];
	public String LetterCapitalize(String str)
	{
		mystr=str.toCharArray();
		for(int i=0;i<str.length();i++)
		{
			//char c=str.charAt(i);
			
			if(mystr[i]==' ')
				mystr[i+1]=(char) (mystr[i+1]-32);
			
			else if(i==0)
				mystr[i]=(char) (mystr[i]-32);

				
		}
		
		for(int i=0;i<str.length();i++)
		{
			System.out.print(mystr[i]);
			
		}
		return newstr;
	}
	
	public static void main(String[] args) {
	
	Que3 q=new Que3();
	Scanner s= new Scanner(System.in);
	System.out.println("enter string");

	q.str=s.nextLine();
	q.out=q.LetterCapitalize(q.str);
	s.close();
	System.out.println(q.out);
	
	
	
	}

}
