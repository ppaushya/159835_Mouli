package org.capgemini.com;

public class Q4 {

	public boolean isArmstrong(int num)
	{
		int tmp,n,c=0;
		boolean flag=false;
		tmp=num;
		while(num>0)
		{
			n=num%10;
			num=num/10;
			c=c+(n*n*n);
		}
		if(tmp==c)
		{
			flag=true;
		}
		return flag;
		
	}
	public static void main(String[] args) {
		Q4 obj=new Q4();
		boolean f;
		for(int i=1;i<1000;i++)
		{
			f=obj.isArmstrong(i);
			if(f==true)
			{
				System.out.println(i+" Is An Armstrong Number");
			}
			else
				System.out.println(i+" Is not an Armstrong Number");
		}
	}

}
