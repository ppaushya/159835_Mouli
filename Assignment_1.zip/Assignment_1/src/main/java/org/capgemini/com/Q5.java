package org.capgemini.com;

public class Q5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String str="hello";
       for(int i=0;i<6;i++)
       {
    	   for(int j=0;j<i;j++) {
    		   System.out.print(str.charAt(j)+" ");
    	   }
    	   System.out.println();
       }
	}

}
