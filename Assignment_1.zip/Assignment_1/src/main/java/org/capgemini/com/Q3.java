package org.capgemini.com;

public class Q3 {
	public boolean isPrime(int num) {
		boolean f=false;
		int i;
		if(num==1)
		{
			f=true;
		}
		for(i=2;i<num;i++)
		{
			
			if(num%i==0)
			{
				f=true;
			}
			
		}
		return f;
	}

	public static void main(String[] args) {
		
	  Q3 obj=new Q3();
	  for(int i=1;i<1000;i++)
	  {
	 boolean f=obj.isPrime(i);
	  if(f==true)
	  System.out.println(i+"Is not a prime");
	  else
		  System.out.println(i+"Is a prime");
	  }
	}

}
