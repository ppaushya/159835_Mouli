package org.cap.model;

import java.util.List;

public class CollectionDemo {
	private List<String> names;
private List<Address> address;
public List<String> getNames() {
	return names;
}
public void setNames(List<String> names) {
	this.names = names;
}
@Override
public String toString() {
	return "CollectionDemo [names=" + names + ", address=" + address + "]";
}
public List<Address> getAddress() {
	return address;
}
public void setAddress(List<Address> address) {
	this.address = address;
}
	
	

}
