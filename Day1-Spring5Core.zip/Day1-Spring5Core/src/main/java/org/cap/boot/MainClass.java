package org.cap.boot;


import org.cap.model.CollectionDemo;
import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("collectionBean.xml");
				//ClassPathXmlApplicationContext("myBeans.xml");
		CollectionDemo demo=(CollectionDemo) context.getBean("myDemo");
		System.out.println(demo);
		Employee employee=(Employee) context.getBean("emp");
		System.out.println(employee);
				
			
				
	
	
	}
}
