package org.capgemini.demo;

import java.util.ArrayList;
import java.util.LinkedList;

public class ListExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> lst=new LinkedList<>();
		LinkedList<String> l=new LinkedList<>();
		l.add("moulya");
		l.add("ram");
		lst.add("tom");
		lst.add("Jeryy");
		lst.add("moul");
		lst.add("ram");
		lst.add(null);
		lst.add("rahim");
		lst.add("mahesh");
		lst.add(3, "Mom");
		lst.addAll(2, l);
		lst.addAll(l);
		l.clear();
		lst.set(5, "Badri");
		lst.remove(5);
		lst.remove(l);
		//lst.trimToSize();
		System.out.println(lst.equals(l));
		System.out.println(lst.spliterator());
		System.out.println( lst.subList(3, 9));
		System.out.println(lst.toArray());
		System.out.println(lst.listIterator(6));
		System.out.println(lst.lastIndexOf("moulya"));
		System.out.println(lst.clone());
		//System.out.println(lst.removeAll(lst));
		System.out.println(lst.contains("moulya"));
		System.out.println(lst.containsAll(lst));
		//lst.hugeCapacity(15);
		System.out.println(lst.size());
		System.out.println(l.isEmpty());
		System.out.println(lst.get(3));
		
	
		
		
		
		for(String str: lst)
		{
			System.out.print(str+", ");
		}
System.out.println();
		
	}

}
