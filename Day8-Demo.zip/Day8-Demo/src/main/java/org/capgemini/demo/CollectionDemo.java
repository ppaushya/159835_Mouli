package org.capgemini.demo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CollectionDemo {

	public static void main(String[] args) {

			//ArrayList
		//ArrayList lst=new ArrayList();
		//ArrayList lst=new ArrayList<>();
		List<Integer> lst=new ArrayList<>();
		//Collection lst=new ArrayList();
		//Iterable lst =new ArrayList();//As iterable is root only parent methods are available
		lst.add(3);
		/*lst.add("Tom");
		lst.add(45.89);
		lst.add(4521332389l);
		lst.add(new Object());
		lst.add(45.89);
		lst.add(45.89);*/
		lst.add(null);
		lst.add(null);


		System.out.println(lst);
		//toString Method is overridden
		System.out.println(lst.get(3));
		
	}

}
