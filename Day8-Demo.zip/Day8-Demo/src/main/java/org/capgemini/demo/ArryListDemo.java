package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class ArryListDemo {

	public static void main(String[] args) {
		
		//ArrayList<String> lst=new ArrayList<>();
		Vector<String> lst=new Vector<>();
		
		lst.add("tom");
		lst.add("Jeryy");
		lst.add("moul");
		lst.add("ram");
		lst.add(null);
		lst.add("rahim");
		lst.add("mahesh");
		//Enhanced for loop
		for(String str: lst)
		{
			System.out.print(str+", ");
		}
System.out.println();
		//Iterator
    Iterator<String> iterator=lst.iterator();
    System.out.println(iterator);
    while(iterator.hasNext())
    {
    	String str=iterator.next();
    	System.out.print(str+", ");
    }
      System.out.println();
      //lIST iTERATOR
      ListIterator<String> lsti=lst.listIterator();
      while(lsti.hasNext())
      {
    	  String str=lsti.next();
    	  System.out.print(str+", ");
      }
      System.out.println();
      //For backward traversal if forward is not there we cannot  do it
      while(lsti.hasPrevious())
      {
    	  String str=lsti.previous();
    	  System.out.print(str+"--> ");
      }
      System.out.println();
      //Enumeration
      Enumeration<String> enumur=lst.elements();
      while(enumur.hasMoreElements()) {
    	  String s=enumur.nextElement();
    	  System.out.print(s+", ");
      }
      System.out.println();
	}

}
