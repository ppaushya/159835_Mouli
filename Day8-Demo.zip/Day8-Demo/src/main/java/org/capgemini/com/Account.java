package org.capgemini.com;
import java.time.LocalDate;
public class Account {
private int accountNo;
private String accountType;
private LocalDate openingDate;
private double openingBalance;
public Account(){
	
}
public int getAccountNo() {
	return accountNo;
}
public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public LocalDate getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(LocalDate openingDate) {
	this.openingDate = openingDate;
}
@Override
public String toString() {
	return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", openingDate=" + openingDate
			+ ", openingBalance=" + openingBalance + "]";
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}

}

