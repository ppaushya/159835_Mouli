package org.capgemini.com;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		List<Account> a=new ArrayList<>();

	}

}
