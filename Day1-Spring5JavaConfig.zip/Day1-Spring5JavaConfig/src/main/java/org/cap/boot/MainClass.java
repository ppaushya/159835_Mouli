package org.cap.boot;

import org.cap.config.MyConfig;

import org.cap.model.Employee;
import org.cap.model.JavaConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new AnnotationConfigApplicationContext(MyConfig.class);
		System.out.println(context.getBean(String.class));
		Employee employee=context.getBean(Employee.class);
		System.out.println(employee);
		
		

	}

}
