package org.cap.config;

import org.cap.model.JavaConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(value= {JavaConfig.class})
public class MyConfig {
	@Bean
	public String sayHello() {
		return "Hello World";
	}

}
