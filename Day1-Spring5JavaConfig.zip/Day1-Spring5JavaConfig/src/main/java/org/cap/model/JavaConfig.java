package org.cap.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration

public class JavaConfig {
	@Bean
//	@Scope("prototype")
	public Employee getEmployeeBean() {
		Employee emp=new Employee();
		emp.setEmployeeId(10);
		emp.setEmployeeName("Mou");
		emp.setSalary(34000);
		return emp;
	}
	/*public Employee getEmployeeBean() {
		return new Employee(1001,"Tom",34000,getAddressBean());
	}*/
	@Bean(name="address")
	public Address getAddress() {
		return new Address("Northy Avne","Chennai");
	}
	@Bean(name="address2")
	public Address getAddressBean() {
		return new Address("South Avne","Pune");
	}

}
