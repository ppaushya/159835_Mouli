package org.capgemini.demo;
//import static org.capgemini.com.Validation;
import static org.capgemini.com.Validation.*;
public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Validation obj=new Validation();
		//obj.demo();
		//Validation.show();
		show();
		//System.out.println("Number"+Validation.num);
		System.out.println("Number"+num);
		//System.out.println("Count"+obj.count);
	}

}
