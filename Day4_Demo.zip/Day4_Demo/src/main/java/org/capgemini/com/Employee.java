package org.capgemini.com;

import java.util.Scanner;

public class Employee {

	String firstName,lastName;
	 int empId,age,salary;
	 Weekdays weekOff;
	 public void getEmpDetails()
	 {
		 Scanner scan=new Scanner(System.in);
		 empId=scan.nextInt();
		 firstName=scan.next();
		 lastName=scan.next();
		 age=scan.nextInt();
		 salary=scan.nextInt();
		 System.out.println("Choose the week off[1-7]");
		 System.out.println("1.MONDAY\n 2.TUESDAY \n 3.WEDNESDAY \n 4.THURSDAY \n 5.FRIDAY \n 6.SATURDAY \n 7.SUNDAY");
		 int num=scan.nextInt();
			
			switch(num)
			{
				case 1:
						weekOff=Weekdays.MON;
						break;
				case 2:
					weekOff=Weekdays.TUES;
					break;
				case 3:
					weekOff=Weekdays.WED;
					break;
				case 4:
					weekOff=Weekdays.THUR;
					break;
				case 5:
					weekOff=Weekdays.FRI;
					break;
				case 6:
					weekOff=Weekdays.SAT;
					break;
				case 7:
					weekOff=Weekdays.SUN;
					break;
				default:
					System.out.println("This is not a weekday");
					break;
			}
	 }
	 public void printDetails()
	 {
		 System.out.println(" Employee details are:");
		 
		 System.out.println("FirstName: "+firstName);
		 System.out.println("LastName: "+lastName);
		 System.out.println("EmployeeId: "+empId);
		 System.out.println("Age: "+age);
		 System.out.println("Salary: "+salary);
		 System.out.println("Week off is on "+weekOff);
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee emp=new Employee();
emp.getEmpDetails();
emp.printDetails();
	}

}
