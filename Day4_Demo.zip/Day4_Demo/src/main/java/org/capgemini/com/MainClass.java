package org.capgemini.com;
import java.util.*;
public class MainClass {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//MainClass m=new MainClass();
		/*Weekdays myday=Weekdays.SUN;
		
		switch(myday)
		{
		case SUN:
			System.out.println("Holiday!");
			break;
		case SAT:
			System.out.println("Learning Day!");
			break;
		case MON:
		case TUES:
		case WED:
			System.out.println("Working Day!");
			break;
			default:
				System.out.println("Special Day!");
				break;
		}*/
		
		Weekdays[] vals=Weekdays.values();
		//Weekdays m=new Weekdays();
		for(Weekdays day:vals)
		{
			System.out.println(day);
		}
		String str="SAT";
		Weekdays yourday=Weekdays.valueOf(Weekdays.class, str);
		System.out.println(yourday);

	}

}
