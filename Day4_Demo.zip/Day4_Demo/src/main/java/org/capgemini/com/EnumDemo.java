package org.capgemini.com;

public class EnumDemo {

	public enum weekdays{
		SUN,MON,TUES,WED,THUR,FRI,SAT
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
