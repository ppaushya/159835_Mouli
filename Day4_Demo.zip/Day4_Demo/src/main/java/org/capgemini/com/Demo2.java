package org.capgemini.com;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Tom";
		String my="Tom";
		String my1="SAam";
		String mystr=new String("Jerry");
		String s=new String("Jerry");
		String m="Jerry";

System.out.println(str);
System.out.println(mystr);
System.out.println(str.hashCode());
System.out.println(mystr.hashCode());
System.out.println(my.hashCode());
System.out.println(my1.hashCode());
System.out.println(s.hashCode());
System.out.println(m.hashCode());



	}

}
