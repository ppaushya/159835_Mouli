package org.capgemini.com;

public enum Weekdays{
	SUN(1),MON(2),TUES(3),WED(4),THUR(5),FRI(6),SAT(7);
	int value;
	//cONSTRUCTOR FOR Weekdays
		private Weekdays(int var)
	{
		this.value=var;
	}
		public int getValue()
		{
			return this.value;
		}
}

