package org.capgemini.com;

public enum Month {

}
