package org.capgemini.com;

 enum CustomerType{
	SILVER(0,100),GOLD(101,200),DIAMOND(201,300),PLATINUM(301,400);
	 int minrewardpoints;
	 int maxrewardpoints;
	 private CustomerType(int minrewardpoints,int maxrewardpoints)
	 {
		 this.minrewardpoints=minrewardpoints;
		 this.maxrewardpoints=maxrewardpoints;
	 }
	 public int getMinValue()
		{
			return this.minrewardpoints;
		}
	 public int getMaxValue()
		{
			return this.maxrewardpoints;
		}
}

public class Customer {
	int customerId=1001;
	String customerName="JIM";
	CustomerType customerType=CustomerType.DIAMOND;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer cust = new Customer();
		System.out.println(cust.customerId+", "+cust.customerName+", "+","+cust.customerType+", "+cust.customerType.getMinValue()+", "+cust.customerType.getMaxValue());
	}

}
