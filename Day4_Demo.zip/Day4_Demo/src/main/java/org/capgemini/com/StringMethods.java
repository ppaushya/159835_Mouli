package org.capgemini.com;

import java.nio.charset.Charset;

public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Tom tomoom";
		String s1="tom";
		char[] s2= {'h','e','y'};
		System.out.println("Character at given Index "+s.charAt(1));
		System.out.println("Code Point at given Index "+s.codePointAt(1));
	int f=s.compareTo(s1);
	int g=s.compareToIgnoreCase(s1);
	if(f==0)
		System.out.println("Two strings are equal");
	else
		System.out.println("Two strings are not equal");
	if(g==0)
		System.out.println("Two strings are equal with case ignored");
	else
		System.out.println("Two strings are not equal with case ignored");
	System.out.println("Concatination of two strings "+s.concat(s1));
	System.out.println("Contains the given string "+s.contains("om"));
	System.out.println("Content Equals "+s.contentEquals(s));
	System.out.println("Copy the value"+s.copyValueOf(s2));
	System.out.println("Copy the value at the "+s.copyValueOf(s2,1,2));
	System.out.println("Ends with"+s.endsWith("om"));
	System.out.println("Strings are equal"+s.equals(s1));
	System.out.println("Strings are equal ignoring cases "+s.equalsIgnoreCase(s1));
  byte[] b= new byte[10];
  b=s.getBytes();
  System.out.println("Byte array is ");
  for(int i=0;i<b.length;i++)
  {
	  System.out.print(b[i]+" ");
  }
  b=s.getBytes(Charset.forName("ASCII"));
  for(int i=0;i<b.length;i++)
  {
	  System.out.print(b[i]+" ");
  }
  
	System.out.println("Hash Code "+s.hashCode());
	System.out.println("Index of "+s.indexOf('o'));
	System.out.println("Index of from index"+s.indexOf('o',1));
	System.out.println("Index of String"+s.indexOf("om"));
	System.out.println("Index of Substring from given index "+s.indexOf("om"));
	System.out.println("Canonical form "+s1.intern());
	System.out.println("Empty "+s.isEmpty());
	System.out.println("Last Index of "+s.lastIndexOf('o'));
	System.out.println("Last Index of from index"+s.lastIndexOf('o',3));
	System.out.println(" Last Index of String "+s.lastIndexOf("om"));
	System.out.println(" Last Index of String "+s.lastIndexOf("om",3));
	System.out.println(" Length of String "+s.length());
	System.out.println("Regular Expression "+s1.matches("[a-zA-Z]"));
	System.out.println(" Value  of String "+s.valueOf(10));
	System.out.println(" Value  of String "+s.valueOf(true));
	System.out.println(" Trim String "+s.trim());





	}
	

}
