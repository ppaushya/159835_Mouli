package org.capgemini.com;

public class Product {
	int productId;
	String productName;
	double price;
	int qty;
	public Product() {
		System.out.println("Default Constructor");
	}
  //constuctor overloading
	public Product(int proId)
	{
		System.out.println("Overloaded constructor with 1 arg");
		this.productId=proId;
	}
	public void printProducts()
	{
		System.out.println("["+productId+",  "+productName+","+price+","+qty+"]");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product pro=new Product();//calls default constuctor
		System.out.println(pro);
		pro.printProducts();
		Product pro2=new Product(10001);//calls Overloaded constructor with 1 arg
		System.out.println(pro2);
		pro2.printProducts();
		Product p1=new Product();
		System.out.println(p1);
		Product p2=new Product();
		System.out.println(p2);
	}
	
}
