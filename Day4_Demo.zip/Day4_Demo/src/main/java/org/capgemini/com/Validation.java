package org.capgemini.com;

public class Validation {
	public int count=100;
	public static int num=10001;
	public void demo()
	{
		System.out.println("Hey this is the instance member");
		System.out.println("Number"+num);
		System.out.println("Count is"+count);
	}
	public static  void show()
	{
		System.out.println("Hey this is the Static member");
		System.out.println("Number"+num);
		//System.out.println("Count is"+count);
	}

}
