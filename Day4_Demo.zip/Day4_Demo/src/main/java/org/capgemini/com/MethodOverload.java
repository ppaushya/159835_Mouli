package org.capgemini.com;

public class MethodOverload {

	public double calculateInterest()
	{
		double res=0;
		double years=1.5,rate=2.5;
		int p=1000;
		res=p*years*rate/100;
		return res;
		
	}
	
	public double calculateInterest(int principle)
	{

		double res=0;
		double years=10,rate=0.5;
		res=principle*years*rate/100;
		
		return res;
	}
	public double calculateInterest(double years,double rate)
	{

		double res=0;
		int p=1000;
		res=p*years*rate/100;
		return res;
	}
	public double calculateInterest(int principle,double years,double rate)
	{

		double res=0;
		res=principle*years*rate/100;
		return res;
		
	}
	
	public static void main(String[] args) {
	
		MethodOverload my=new MethodOverload();
		int p=3000;
		double n=5,r=0.13;
		System.out.println("Output from method 1 is "+my.calculateInterest());
		System.out.println("Output from method 2 is "+my.calculateInterest(p));
		System.out.println("Output from method 3 is "+my.calculateInterest(n,r));
		System.out.println("Output from method 4 is "+my.calculateInterest(p,n,r));
		
	}

}
