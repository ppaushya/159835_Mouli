package org.capgemini.com;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,num;
		if(args.length>0)
		{
			for(String str:args)
			{
				System.out.println(str);
				num=Integer.parseInt(str);
				sum=sum+num;
				
			}
			System.out.println(sum);
		}
	}

}
