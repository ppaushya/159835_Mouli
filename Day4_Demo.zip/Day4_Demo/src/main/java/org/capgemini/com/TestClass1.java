package org.capgemini.com;
import java.util.*;
public class TestClass1 {
public void binarySearch(int[] arr)
{
	 int mid=0;
	Arrays.sort(arr);
	if(arr.length%2==0)
	{
		mid=arr.length/2;
	}
	else 
		mid=arr.length/2+1;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {10,30,40,0,-2,-11,23};
		//Arrays.sort(arr);
		//sort is only in ascending order
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		String[] nam= {"tom","mou","ram","puppy","badri"};
		Arrays.sort(nam);
		for(int i=0;i<nam.length;i++)
		{
			System.out.print(nam[i]+" ");
		}
		System.out.println();
		//int[] myArr=Arrays.copyOf(arr,arr.length);
		int[] myArr=Arrays.copyOfRange(arr,2,arr.length);
		//System.out.println(arr);
		//System.out.println(myArr);
		
		for(int i=0;i<myArr.length;i++)
		{
			System.out.print(myArr[i]+" ");
		}
		System.out.println();
		int res=Arrays.binarySearch(arr, 40);
		System.out.println(res);
		
	}

}
