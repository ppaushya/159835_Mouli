

public class Dem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="tom";
		String str1=new String("tom");
		String str2="tom";
		String str3=new String("tom");
		System.out.println(str==str1);
		System.out.println(str.equals(str1));
		System.out.println(str==str2);
		System.out.println(str==str3);
		System.out.println(str1==str3);
		System.out.println(str1.equals(str3));


		
	}

}
