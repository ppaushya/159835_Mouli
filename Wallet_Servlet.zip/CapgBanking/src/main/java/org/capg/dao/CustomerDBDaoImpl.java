package org.capg.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDBDaoImpl implements ICustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		
		
		List<Customer> lst=new ArrayList<>();
		String str="select * from customer;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Customer customer=new Customer();
				Address address=new Address();
				
				
				String strAddress="select * from address where customerId="+resultSet.getInt(1)+";";

				PreparedStatement statement1=connection.prepareStatement(strAddress);
				ResultSet resultSet1= statement1.executeQuery();
				
				while(resultSet1.next())
				{
					address.setAddressLine1(resultSet1.getString(2));
					address.setAddressLine2(resultSet1.getString(3));
					address.setCity(resultSet1.getString(4));
					address.setState(resultSet1.getString(5));
					address.setPinCode(resultSet1.getLong(6));
				}
				
			
				
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setEmailId(resultSet.getString(5));
				customer.setMobile(resultSet.getString(6));
				customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
				customer.setAddress(address);
				
				lst.add(customer);
			}
		}	catch (SQLException e) {
			
			e.printStackTrace();
		}
		return lst;
		
	}

	@Override
	public void createCustomer(Customer customer) {
	
		
		String sql="insert into customer(firstName,lastName,dateOfBirth,emailId,mobile,password)"+" values(?,?,?,?,?,?);";
		String sqlAddr="insert into address(addressLine1,addressLine2,city,state,pincode,customerId)"+" values(?,?,?,?,?,?);";
		boolean flag=false;
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
			statement.setString(1, customer.getFirstName());
			statement.setString(2, customer.getLastName());
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobile());
			statement.setDate(3, java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(6, customer.getPassword());
			int row=statement.executeUpdate();
			if(row>0)
				flag=true;
			else 
				flag=false;
			if(flag) {
			String sql1="select max(customerId) from customer;";
			
			
			PreparedStatement statement2=connection.prepareStatement(sql1);
		  ResultSet res=statement2.executeQuery();
		  int customerId=100;
			while(res.next())
			{
				customerId=res.getInt(1);
				customer.setCustomerId(customerId);
			}
			Address address=customer.getAddress();
			
			PreparedStatement statement1=connection.prepareStatement(sqlAddr);
		
			statement1.setString(1, address.getAddressLine1());
			statement1.setString(2, address.getAddressLine2());
			statement1.setString(3, address.getCity());
			statement1.setString(4, address.getState());
			statement1.setLong(5, address.getPinCode());
			statement1.setInt(6, customerId);
			
			
		
			int rowAddr=statement1.executeUpdate();
				if(rowAddr>0)
				flag=true;
				else 
					flag=false;
			}	
			else 
				flag=false;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
