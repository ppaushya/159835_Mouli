package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao	{
	
	
	@Override
	public Set<Account> getAccountsOfCustomer(Customer customer)
	{
		Set<Account> accounts=new HashSet<>();
		String str="select * from account where customerId=?";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, customer.getCustomerId());
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Account account=new Account();
				
				
				
					account.setAccountNo(resultSet.getLong(1));
					account.setAccountType(AccountType.valueOf(resultSet.getString(2)));
					account.setOpeningDate(resultSet.getDate(3).toLocalDate());
					account.setOpeningBalance(resultSet.getDouble(4));
					account.setDescription(resultSet.getString(5));
					account.setCustomer(customer);
					
					accounts.add(account);
			
			}
		}	catch (SQLException e) {
			
			e.printStackTrace();
		}
		if(accounts.isEmpty())
		{
			return null;
		}
		else
		return accounts;
	}
	
	@Override
	public void createAccount(Account account)
	{
		String sqlAcc="select max(accountNumber) from account;";
		int accountNo=0;
	
		String sql="insert into account values(?,?,?,?,?,?);";
		
		
		try(Connection connection=getConnection())
		{
			
			PreparedStatement statement2=connection.prepareStatement(sqlAcc);
		  ResultSet res=statement2.executeQuery();
			if(res.next())
			{
				accountNo=res.getInt(1);
				//accountNo=10000;
				if(accountNo==0)
				{
					accountNo=10000;
				}
				else
					accountNo+=1;
			}
			account.setAccountNo(accountNo);
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(6, account.getCustomer().getCustomerId());
			statement.setLong(1, account.getAccountNo());
			statement.setString(2, account.getAccountType().toString());
			statement.setDate(3, java.sql.Date.valueOf(account.getOpeningDate()));
			statement.setDouble(4, account.getOpeningBalance());
			statement.setString(5, account.getDescription());
			
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Accounts table!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Account> getAccounts(Customer customer) {
		
		Set<Account> accounts=new HashSet<>();
		String str="select * from account where customerId!=?";
		//String str1 = "select customerId from account where accountNo=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, customer.getCustomerId());
			ResultSet resultSet= statement.executeQuery();
		
			
			while(resultSet.next())
			{
				Account account=new Account();
				
				
				
					account.setAccountNo(resultSet.getLong(1));
					account.setAccountType(AccountType.valueOf(resultSet.getString(2)));
					account.setOpeningDate(resultSet.getDate(3).toLocalDate());
					account.setOpeningBalance(resultSet.getDouble(4));
					account.setDescription(resultSet.getString(5));
					customer.setCustomerId(resultSet.getInt(6));
					account.setCustomer(customer);
					accounts.add(account);
			
			}
			
			
		}	catch (SQLException e) {
			
			e.printStackTrace();
	}
		if(accounts.isEmpty())
		{
			return null;
		}
		else
		return accounts;
	}
	
public Account getAccount(long  accountno)
{
	String str1 = "select * from account where accountNumber=?";
	Account account=new Account();
	//Customer cust=account.getCustomer();
	try(Connection connection=getConnection())
	{
		PreparedStatement statement=connection.prepareStatement(str1);
		statement.setLong(1, accountno);
		ResultSet resultSet= statement.executeQuery();
		
		
	
		
		while(resultSet.next())
		{
			account.setAccountNo(resultSet.getLong(1));
			account.setAccountType(AccountType.valueOf(resultSet.getString(2)));
			account.setOpeningDate(resultSet.getDate(3).toLocalDate());
			account.setOpeningBalance(resultSet.getDouble(4));
			account.setDescription(resultSet.getString(5));
			
		}
		
		
	}	catch (SQLException e) {
		
		e.printStackTrace();
}
	
	return account;
}


}
