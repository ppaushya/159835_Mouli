package org.capg.hbms.dao;

import java.util.Set;

import org.capg.hbms.model.BookingDetails;

public interface IBookingDao {
	
public void addbooking(BookingDetails bookingdetails);
public Set<BookingDetails> getBookingDetails(int customerId);

}
