package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.dao.IRegistrationDao;
import org.capg.hbms.dao.RegistrationDaoImpl;
import org.capg.hbms.model.Users;

public class RegistrationServiceImpl implements IRegistrationService {

	IRegistrationDao registerDao=new RegistrationDaoImpl();
	public RegistrationServiceImpl(){
	}
	public RegistrationServiceImpl(IRegistrationDao registerDao) {
		super();
		this.registerDao = registerDao;
	}
	@Override
	public Users createUser(Users user) {
		
		return registerDao.createUser(user);
	}
	public List<Users> getAllUsers()
	{
		return registerDao.getAllUsers();
	}

}
