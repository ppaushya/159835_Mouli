package org.capg.hbms.service;

import org.capg.hbms.dao.IRegistrationDao;
import org.capg.hbms.dao.RegistrationDaoImpl;
import org.capg.hbms.model.Users;

public class RegistrationServiceImpl implements IRegistrationService {

	IRegistrationDao registerDao=new RegistrationDaoImpl();
	@Override
	public Users createUser(Users user) {
		
		return registerDao.createUser(user);
	}

}
