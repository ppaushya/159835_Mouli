package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.hbms.model.Users;

public class RegistrationDaoImpl implements IRegistrationDao {

	@Override
	public Users createUser(Users user) {
		
     String sql="insert into users(password,role,user_name,mobile_no,phone,address,email) values(?,?,?,?,?,?,?);";
		
		
		try(Connection connection=getConnection())
		{
			
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1,user.getPassword());
			statement.setString(2,user.getRole());
			statement.setString(3, user.getUser_name());
			statement.setString(4,user.getMobile_no());
			statement.setString(5,user.getPhone());
			statement.setString(6,user.getAddress());
			statement.setString(7,user.getEmail());

			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" User Registered successfully!");
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Users> getAllUsers()
	{
		String sql="select * from Users ";
		List<Users> users=new ArrayList<>();
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
		
		  ResultSet res=statement.executeQuery();
		if(res.next())
			{
				Users user1 =new Users();
				user1.setUser_id(res.getInt(1));
				user1.setPassword(res.getString(2));
				user1.setRole(res.getString(3));
				user1.setUser_name(res.getString(4));
				user1.setMobile_no(res.getString(5));
				user1.setPhone(res.getString(6));
				user1.setAddress(res.getString(7));
				user1.setEmail(res.getString(8));
				 users.add(user1);
				 return users;
				
			}
		else
		{
			System.out.println("No users to dispaly");
			System.exit(0);//else go to home screen
		}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


	
}
