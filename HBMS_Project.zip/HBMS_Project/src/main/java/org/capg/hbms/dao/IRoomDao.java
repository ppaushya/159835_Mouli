package org.capg.hbms.dao;

import java.util.List;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.RoomDetails;

public interface IRoomDao {

	void addRoom(RoomDetails room);

	List<RoomDetails> getRooms(int hotel_id);

	Double roomRate(int roomid);

	void changeAvailability(RoomDetails finalroom);

	RoomDetails getRoom_withID(int room_id);

	void deleteRoom(int roomid);

	void setAvailability(RoomDetails roomd);

	void changeRoomType(RoomDetails roomdetail);

	void changeRoomCost(RoomDetails roomdetail);

}
