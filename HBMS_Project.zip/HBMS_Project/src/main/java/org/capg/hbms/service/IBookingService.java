package org.capg.hbms.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.capg.hbms.model.BookingDetails;

public interface IBookingService {
	public void addbooking(BookingDetails bookingdetails);
	public BookingDetails findAmount(BookingDetails bookingDetails);
	public Set<BookingDetails> getBookingDetails(int customerId);
	public List<BookingDetails> getBookings(LocalDate of);
	public List<BookingDetails> getBookingOfHotel(int hotelId);
}
