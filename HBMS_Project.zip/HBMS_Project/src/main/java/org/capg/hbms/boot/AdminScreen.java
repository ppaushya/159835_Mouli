package org.capg.hbms.boot;

import java.util.Scanner;

import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IHotelService;
import org.capg.hbms.service.IRoomService;
import org.capg.hbms.service.RoomServiceImpl;
import org.capg.hbms.view.AdminInteraction;

public class AdminScreen {
	static Scanner scanner=new Scanner(System.in);
	static IHotelService hotelservice=new HotelServiceImpl();

	public static void HotelManagement()
	{
		AdminInteraction admininteraction=new AdminInteraction();
		String option1="";
		do {
		System.out.println("Choose Functionality");
		System.out.println("1. Add Hotel");
		System.out.println("2.Delete Hotel");
		System.out.println("3.Modify Hotel");
		
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			Hotel hotel1=admininteraction.PromptHotel();
			hotelservice.addHotel(hotel1);
			
			break;
		case 2:
			
			int hotelid=admininteraction.DeleteHotel();
			hotelservice.deleteHotel(hotelid);
			
		break;
		case 3:
			admininteraction.modifyHotel();
			break;
			
		}
		System.out.println("Do you wish to do more hotel management [Y|N]");
		option1=scanner.next();
	}while(option1.charAt(0)=='Y'||option1.charAt(0)=='y');	
	}
	
	public static void RoomManagement()
	{
		System.out.println("Choose Functionality");
		System.out.println("1. Add Room");
		System.out.println("2.Delete Room");
		System.out.println("3.Modify Room");
		int choice=scanner.nextInt();
		AdminInteraction admininteraction=new AdminInteraction();
		IRoomService roomservice=new RoomServiceImpl();
		switch(choice)
		{
		case 1:
			RoomDetails room=new RoomDetails();
			room=admininteraction.promptRoom();
			roomservice.addroom(room);
			
			break;
		case 2:
			int roomid;
				roomid=admininteraction.promptRoomid();	
			roomservice.deleteRoom(roomid);
			
		break;
		case 3:
			System.out.println("Choose Functionality");
			System.out.println("1.Change availability");
			System.out.println("2.Change room Name");
			System.out.println("3.Change per Night Cost");
			int option=scanner.nextInt();
			switch(option)
			{
			case 1:
				RoomDetails roomd=admininteraction.changeAvailability();
				
				roomservice.setAvailability(roomd);
				break;
			case 2:
				
				RoomDetails roomdetail=admininteraction.changeRoomType();
				
				roomservice.changeRoomType(roomdetail);
				break;
			case 3:
				
				RoomDetails roomdetail2=admininteraction.changeRoomCost();
				
				roomservice.changeRoomCost(roomdetail2);
				
				break;
				default:
					System.out.println("Invalid Option");
					break;
			}
			
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}
	}
	public static void GenerateReports()
	{
		AdminInteraction.GenerateReports();
		System.out.println("Choose Functionality");
		System.out.println("1.View List of hotels");
		System.out.println("2.View Users");
		//System.out.println("2.View Bookings for specific Hotel");
		System.out.println("3.View Bookings for specific Date");
		
	}
	public static void adminMain() {
		String option="";
		Scanner scanner=new Scanner(System.in);
		do
			{
			System.out.println("Choose functionality");
		
		System.out.println("1.Hotel Management");
		System.out.println("2.Room Management");
		System.out.println("3.Generate Reports");
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			HotelManagement();
			break;
		case 2:
			RoomManagement();
		break;
		case 3:
			GenerateReports();
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}
		
		System.out.println("Do you wish to continue [Y|N]");
		 option=scanner.next();
	}while(option.charAt(0)=='Y'||option.charAt(0)=='y');	
		
	}

}
