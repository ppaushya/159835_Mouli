package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.dao.HotelDaoImpl;
import org.capg.hbms.dao.IHotelDao;
import org.capg.hbms.model.Hotel;

public class HotelServiceImpl implements IHotelService {
	IHotelDao hoteldao=new HotelDaoImpl();
	@Override
	public void addHotel(Hotel hotel) {
		hoteldao.addHotel(hotel);
		
	}
	public void deleteHotel(int hotelid) {
		hoteldao.deleteHotel(hotelid);
		
	}

	@Override
	public List<Hotel> getHotels(String City) {
		
		return hoteldao.getHotels(City);
	}
	public void modifyHotelDescription(String str,int hotelid)
	{
		 hoteldao.modifyHotelDescription(str,hotelid);
	}
	public Hotel getHotel_id(int id)
	{
		return hoteldao.getHotel_id(id);
	}
	public List<Hotel> getAllHotels() 
	{
		return hoteldao.getAllHotels();
	}
	public void modifyHotelName(String str,int hotelid)
	{
		hoteldao.modifyHotelName(str, hotelid);
	}
	public void modifyHotelRate(double rate,int hotelid)
	{
		hoteldao.modifyHotelRate(rate, hotelid);
	}
}
