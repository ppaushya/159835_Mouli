package org.capg.hbms.model;

public class RoomDetails {
	private int hotel_id;
	private String room_id,room_no;
   private	RoomType room_type;
	private double per_night_rate;
	private boolean availability;
	private String photo; //The path of image file 
	
	public RoomDetails() {
		
	}

	public RoomDetails(int hotel_id, String room_id, String room_no, RoomType room_type, double per_night_rate,
			boolean availability, String photo) {
		super();
		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
		this.photo = photo;
	}

	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	public String getRoom_id() {
		return room_id;
	}

	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}

	public String getRoom_no() {
		return room_no;
	}

	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}

	public RoomType getRoom_type() {
		return room_type;
	}

	public void setRoom_type(RoomType room_type) {
		this.room_type = room_type;
	}

	public double getPer_night_rate() {
		return per_night_rate;
	}

	public void setPer_night_rate(double per_night_rate) {
		this.per_night_rate = per_night_rate;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	@Override
	public String toString() {
		return "RoomDetails [hotel_id=" + hotel_id + ", room_id=" + room_id + ", room_no=" + room_no + ", room_type="
				+ room_type + ", per_night_rate=" + per_night_rate + ", availability=" + availability + ", photo="
				+ photo + "]";
	}
	

}
