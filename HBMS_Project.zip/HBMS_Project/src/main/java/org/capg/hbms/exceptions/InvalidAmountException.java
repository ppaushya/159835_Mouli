package org.capg.hbms.exceptions;

public class InvalidAmountException extends Exception {
public  InvalidAmountException(String msg)
{
	super(msg);
}
}
