package org.capg.hbms.service;

import org.capg.hbms.model.Users;

public interface ILoginService {
	public Users getUser(Users user);

	public Users getAdmin(Users user1);

}
