package org.capg.hbms.util;

import java.time.LocalDate;

public class Utility {
	
	public boolean isValidRole(String role) {
		
		if(role.equals("User")||role.equals("Employee")||role.equals("Admin"))
			return true;
		
		else return false;
		
	}
	
	public boolean isValidUserName(String user_name) {
	 return user_name.matches("[a-zA-Z]{3,}");
	}
	
	public  boolean isValidMobileNo(String mobile_no) {
		
		return mobile_no.matches("[1-9]{1}[0-9]{9}");
	}
	
	public  boolean isValidEmail(String email) {
		
		return email.matches("[a-z]+@[a-z]+.com");
	}
	
	public  boolean isValidPhoneNo(String phone) {
		return phone.matches("[1-9]{1}[0-9]{5}");
		
	}
	
	public  boolean isValidPassword(String password) {
		return  password.matches("[a-zA-Z]{5}");
		
		
	}

	public Boolean isvalidFromdate(LocalDate frmdate) {
		boolean flag=false;
		if(frmdate.compareTo(LocalDate.now())>0 || frmdate.equals(LocalDate.now())) {
			flag=true;
		}
		return flag;
	}
	
	public Boolean isvalidTodate(LocalDate todate,LocalDate frmdate) {
		boolean flag=false;
		if(todate.isAfter(frmdate)||todate.equals(frmdate)) {
			
			flag=true;
		}
		return flag;
	}
	

}
