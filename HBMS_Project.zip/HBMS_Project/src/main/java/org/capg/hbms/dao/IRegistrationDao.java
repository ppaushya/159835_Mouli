package org.capg.hbms.dao;

import java.util.List;

import org.capg.hbms.model.Users;

public interface IRegistrationDao {
	
	public Users createUser(Users user);
	public List<Users> getAllUsers();

}
