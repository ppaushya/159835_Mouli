package org.capg.hbms.service;

import java.time.LocalDate;
import java.util.List;

import org.capg.hbms.model.Hotel;

public interface IHotelService {
	public void addHotel(Hotel hotel);
	public List<Hotel> getHotels(String City);
	public void deleteHotel(int hotelid);
	public void modifyHotelDescription(String str,int hotelid);
	public Hotel getHotel_id(int id);
	public List<Hotel> getAllHotels() ;
	public void modifyHotelName(String str,int hotelid);
	public void modifyHotelRate(double rate,int hotelid);
	
}
