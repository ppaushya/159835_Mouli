package org.capg.hbms.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.capg.hbms.model.Hotel;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IHotelService;

public class AdminInteraction {
	static IHotelService hotelservice=new HotelServiceImpl();
	 static Scanner sc=new Scanner(System.in);
public Hotel PromptHotel()
{
	String option2;
	do{Hotel hotel=new Hotel();
	System.out.println("Enter city");
	hotel.setCity(sc.next());
	System.out.println("Enter Hotel name");
	hotel.setHotel_name(sc.next());
	System.out.println("Enter Address");
	hotel.setAddress(sc.next());
	System.out.println("Enter description");
	hotel.setDescription(sc.next());
	System.out.println("Enter phone no ");
	hotel.setPhone_no1(sc.next());
	System.out.println("Enter alternate phone number");
	hotel.setPhone_no2(sc.next());
	System.out.println("Enter Average cost per night");
	hotel.setAvg_rate_per_night(sc.nextDouble());
	System.out.println("Enter rating");
	hotel.setRating(sc.next());
	System.out.println("Enter email");
	hotel.setEmail(sc.next());
	System.out.println("Enter fax");
	hotel.setFax(sc.next());

	System.out.println("Do you wish to add more hotels [Y|N]");
	option2=sc.next();
	return hotel;
}while(option2.charAt(0)=='Y'||option2.charAt(0)=='y');

}

public static  void GenerateReports()
{
	System.out.println("Choose Functionality");
	System.out.println("1.View List of hotels");
	System.out.println("2.View Guest List of specific Hotel");
	System.out.println("3.View Bookings for specific Hotel");
	System.out.println("4.View Bookings for specific Date");
	switch(sc.nextInt())
	{
	case 1:
		printHotels(hotelservice.getAllHotels());
		break;
	case 2:
		System.out.println("Enter the HotelId of the hotel whose guestlist you wish to see");
		
		break;
	case 3:
		break;
	case 4:
		break;
		default:
			System.out.println("Invalid Option");
			break;
	}
	
}
public int DeleteHotel()
{
	String option2;
	do{
		printHotels(hotelservice.getAllHotels());
	System.out.println("Enter the id of the hotel u want to delete ");
	int id=sc.nextInt();

	System.out.println("Do you wish to delete more hotels [Y|N]");
	option2=sc.next();
	return id;
}while(option2.charAt(0)=='Y'||option2.charAt(0)=='y');
	
}
public static void printHotels(List<Hotel> hotels)
{
	System.out.println("HotelId\tCity\tHotel_name\tAddress\tDescription\t\tAverageRate\tPhoneNo\tRating\tEmail");
	for(Hotel hotel:hotels)
	{
		
		System.out.println(hotel.getHotel_id()+"\t"+hotel.getCity()+"\t"+hotel.getHotel_name()+"\t"+hotel.getAddress()+"\t"+hotel.getDescription()+"\t\t"+hotel.getAvg_rate_per_night()+"\t"+hotel.getPhone_no1()+"\t"+hotel.getRating()+"\t"+hotel.getEmail());
	}
}
public void modifyHotel()
{
	printHotels(hotelservice.getAllHotels());
	System.out.println("Choose the hotel u want to modify.Enter the hotelid");
	int hid=sc.nextInt();
	List<Hotel> hotels=new ArrayList();
	hotels.add(hotelservice.getHotel_id(hid));
	printHotels(hotels);
	System.out.println("choose what you want to modify.");
	System.out.println("1.Description");
	System.out.println("2.Hotel Name");
	System.out.println("3.Average Rate per night");
	int choice =sc.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("Enter the description you want to set");
		String str=sc.next();
		hotelservice.modifyHotelDescription(str,hid);
		break;
	case 2:
		System.out.println("Enter the hotel name you want to set");
		String str1=sc.next();
		hotelservice.modifyHotelName(str1, hid);
		break;
		
	case 3:
		System.out.println("Enter the new rate you want to set");
		double rate=sc.nextDouble();
		hotelservice.modifyHotelRate(rate, hid);
		break;
		default:
			System.out.println("Invalid Choice");
			break;
		
	}
	
	
}

}
