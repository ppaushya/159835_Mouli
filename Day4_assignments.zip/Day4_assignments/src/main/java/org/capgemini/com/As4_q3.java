package org.capgemini.com;

import java.util.Scanner;

public class As4_q3 {
	public void letterCapitalize(String str)
	{
	char[] mystr=new char[str.length()];
	
	for(int i=0;i<mystr.length;i++)
	{
		
		mystr[i]=str.charAt(i);
	}
	if(mystr[0]>='A' && mystr[0]<='Z')
		mystr[0]=mystr[0];
	else
		mystr[0]=(char) (mystr[0]-(char)(32));
	for(int i=0;i<mystr.length;i++)
	{
		if(mystr[i]>='A' && mystr[i]<='Z')
			mystr[i]=mystr[i];
		else if(mystr[i]==' ')
		{
			mystr[i+1]= (char) (mystr[i+1]-(32));
		}
	
	}
	
	
		for(int i=0;i<mystr.length;i++)
		{
			System.out.print(mystr[i]);
		}
	
}
	public static void main(String[] args) {
		As4_q3 obj=new As4_q3();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=scan.nextLine();
		obj.letterCapitalize(s);

	}

}
