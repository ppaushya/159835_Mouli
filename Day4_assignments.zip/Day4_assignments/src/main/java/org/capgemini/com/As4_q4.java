package org.capgemini.com;
import java.util.Scanner;

public class As4_q4 {
	public String letterChange(String str)
	{ 
	String s="";
	  char[] arr=new char[str.length()];
	  for(int i=0;i<str.length();i++)
	  {
		  arr[i]=str.charAt(i);
		 if(arr[i]>='a' && arr[i]<='z') 
		 {
			 arr[i]=(char) (arr[i]+1);
		 }
		  if(arr[i]=='a'||arr[i]=='e'||arr[i]=='i'||arr[i]=='o'||arr[i]=='u')
		  {
			  arr[i]=(char) (arr[i]-(char)(32));
		  }
	  }
	   for(int i=0;i<str.length();i++)
	  {
		  s=s+arr[i];
	  }
	  return s;
	  
	}
	public static void main(String[] args)
	{
	  As4_q4 obj=new As4_q4();
	  Scanner scan=new Scanner(System.in);
	  System.out.println("Enter the string:");
	  String s1=scan.nextLine();
	  String res=obj.letterChange(s1);
	  System.out.println("Changed string is:");
	  System.out.println(res);
	  
	  
	   
	}
}
