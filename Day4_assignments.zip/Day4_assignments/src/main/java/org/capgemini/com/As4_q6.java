package org.capgemini.com;
import java.util.Scanner;


public class As4_q6 {
	public int firstFactorial(int num)
	{ 
	int res=1;
	for(int i=1;i<=num;i++)
	{
		res=res*i;
	}

	return res;

	}
	public static void main(String[] args)
	{
	 
	  As4_q6 my =new As4_q6();
	  Scanner scan=new Scanner(System.in);
	  System.out.println("Enter te number");
	  int n=scan.nextInt();
	  if(n>=1 && n<=18)
	  {
	  int fact=my.firstFactorial(n);
	  System.out.println("Factorial of  "+n+"is: "+fact);
	  }
	  else
	  {
		  System.out.println("Number should be b/w 1 and 18");

		  System.exit(0);
	  }
	  
	  
	  
	   
	}
}
