package org.capgemini.com;

import java.util.Scanner;

public class As4_q7 {
	
public String longestWord(String str)
{
	String s="",maxWord="";
	int maxlen=0,p=0;
	for(int i=0;i<str.length();i++)
	{

		if(str.charAt(i)!=' ')
		{
			s=s+str.charAt(i);
		}
		else
		{
			p=s.length();
			if((int) p>maxlen)
			{
				maxlen=p;
				maxWord=s;
			}
			s="";
			
		}
	}
	
	return maxWord;
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 As4_q7 obj=new As4_q7();
		  Scanner scan=new Scanner(System.in);
		  System.out.println("Enter the string: ");
		  String s1=scan.nextLine();
		 String longWord=obj.longestWord(s1);
		 System.out.println("This is the longest word in the sentence is "+longWord);
	}

}
