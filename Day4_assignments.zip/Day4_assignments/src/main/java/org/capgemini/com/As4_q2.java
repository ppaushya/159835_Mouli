package org.capgemini.com;
import java.util.Scanner;
public class As4_q2 {
public void AlphabetSoup(String str)
{
	char[] mystr=new char[str.length()];
	char temp1;
	for(int i=0;i<str.length();i++)
	{
		mystr[i]=str.charAt(i);
	}
	
	for(int i=0;i<mystr.length;i++)
	{
		for(int j=i+1;j<mystr.length;j++)
		{
			if(mystr[j]<mystr[i])
		  {
			temp1=mystr[i];
			mystr[i]=mystr[j];
			mystr[j]=temp1;
		  }
			
		}
		
	}
	for(int i=0;i<mystr.length;i++)
	{
		System.out.print(mystr[i]);
	}
	
}
	public static void main(String[] args) {
		
		As4_q2 obj=new As4_q2();
		Scanner scan=new Scanner(System.in);
		String s=scan.next();
		obj.AlphabetSoup(s);

	}

}
