package org.capgemini.com;
import java.util.Scanner;

public class As4_q8 {
	public String AlphabetSoup(String str)
	{
		char[] mystr=new char[str.length()];
		char temp1;
		String s="";
		for(int i=0;i<str.length();i++)
		{
			mystr[i]=str.charAt(i);
		}
		
		for(int i=0;i<mystr.length;i++)
		{
			for(int j=i+1;j<mystr.length;j++)
			{
				if(mystr[j]<mystr[i])
			  {
				temp1=mystr[i];
				mystr[i]=mystr[j];
				mystr[j]=temp1;
			  }
				
			}
			
		}
		  for(int i=0;i<str.length();i++)
		  {
			  s=s+mystr[i];
		  }
		  return s;
	}
	public void anagram(String str,String str1)
	{
	    str=AlphabetSoup(str);
	    //System.out.println(str);
		str1=AlphabetSoup(str1);
		if(str.equals(str1))
		{
			  System.out.println("Two strings are anagrams ");

		}
		else
		{
			System.out.println("Two strings are not anagrams ");
			System.exit(0);
		}
	}
	public static void main(String[] args)
	{
	  As4_q8 obj=new As4_q8();
	  Scanner scan=new Scanner(System.in);
	  System.out.println("Enter the string 1 in small letters: ");
	  String s1=scan.nextLine();
	  System.out.println("Enter the string 2 in small letters : ");
	  String s2=scan.nextLine();
	  obj.anagram(s1,s2);
	  
	  
	  
	   
	}
}
