package org.capgemini.com;

import java.util.Scanner;

public class As4_q5 {
	public String ReverseOrder(String str)
	{ String s="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			s=s+str.charAt(i);
		}
		return s;
	}
	public static void main(String[] args)
	{
	  As4_q5 obj=new As4_q5();
	  Scanner scan=new Scanner(System.in);
	  System.out.println("Enter the string:");
	  String s1=scan.nextLine();
	  String res=obj.ReverseOrder(s1);
	  System.out.println("Reversed string is:");
	  System.out.println(res);
	  
	  
	   
	}
}
