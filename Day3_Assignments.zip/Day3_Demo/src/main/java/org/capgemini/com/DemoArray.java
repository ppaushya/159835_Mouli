package org.capgemini.com;
import java.util.*;

public class DemoArray {
    int[] myArr; 
    int[] temp,arr;
    int temp1;
    public void getArrayElements(int size)
    {
    	Scanner scan=new Scanner(System.in);
    	myArr=new int[size];
    	System.out.println("Enter"+size+"Array Elements:");	
    	for(int i=0;i<size;i++)
    	{
    		myArr[i]=scan.nextInt();
    	}
    	scan.close();
    }
    public void printArrayElements()
    {
    	for(int i=0;i<myArr.length;i++)
    	{
    		System.out.println(myArr[i]);	
    	}
    }
    public void printReverese(int[] arr,int size)
    {
    	int j=0;
    	 temp=new int[size];
    	for(int i=size-1;i>=0;i--,j++)
    	{
    		temp[j]=arr[i];
    		
    		
    	}
    }
    public void  bubbleSortArray() {
    	//a=new int[size];
    
    	for(int i=0;i<myArr.length;i++)
    	{
    		for(int j=i+1;j<myArr.length;j++)
    		{
    			if(myArr[j]<myArr[i])
    		  {
    			temp1=myArr[i];
    			myArr[i]=myArr[j];
    			myArr[j]=temp1;
    		  }
    			
    		}
    		
    	}
    }
    public int bigElement()
    {
    	int big=arr[0];
    	for(int i=1;i<arr.length;i++)
    	{
    		if(big<arr[i])
    		{
    			big=arr[i];
    		}
    	}
    	return big;
    	
    }
    public int smallElement()
    {
    	int small=arr[0];
    	for(int i=1;i<arr.length;i++)
    	{
    		if(small>arr[i])
    		{
    			small=arr[i];
    		}
    	}
    	return small;
    	
    }
    
    
    public void evenNums()
  
    {
    	int sum=0;
    	System.out.println("Even numbers in an array");
    	for(int i=0;i<arr.length;i++)
    	{
    		if(arr[i]%2==0)
    		{
    			sum=sum+arr[i];
    			System.out.println(arr[i]);
    		}
    	}
    	System.out.println("This is sum of even numbers :"+sum);

    	
    	
    }
    public int findSmallestElement(int[] arr1)
    {
    	int min=0;
    	bubbleSortArray();
    	for(int i=1;i<arr.length;i++)
    	{
    		if(arr[i-1]==arr[i]-1)
    		
    			min=arr[arr.length-1]+1;
    		else
    			min=arr[0]+1;
    	}
    	return min;
    }
	public static void main(String[] args) {
		DemoArray obj=new DemoArray();
	  System.out.println("Enter the size of array:");
	  Scanner scan=new Scanner(System.in);
	
	  int n=scan.nextInt();
	  
	  //to get and print the elements of an array
		obj.getArrayElements(n);
		obj.printArrayElements();
		obj.arr=new int[n];
		//to create another array
		System.out.println("Second Array");
		for(int i=0;i<obj.myArr.length;i++)
		{
			obj.arr[i]=obj.myArr[i];	
			System.out.println(obj.arr[i]);	
		}
		
		//to print the reversed array of an array
		obj.printReverese(obj.myArr, n);
		System.out.println("Reversed Array");	
		for(int i=0;i<n;i++)
		{
			obj.myArr[i]=obj.temp[i];	
			System.out.println(obj.myArr[i]);	
		}
		
		//to print the sorted array of an array
		obj.bubbleSortArray();
		
		System.out.println("Sorted Array in ascending order");
		for(int i=0;i<obj.myArr.length;i++)
		{
			
			System.out.println(obj.myArr[i]);	
		}
		// to print the largest element from an array
		int biggest=obj.bigElement();
		System.out.println("Biggest Element is:"+biggest);	
		
		//to print the Smallest element from an array
		int smallest=obj.smallElement();
		System.out.println("Smallest Element is:"+smallest);	
		//to print the even numbers and sum of even numbers from an array
		obj.evenNums();
		
		//to print Smallest min of sequence
		System.out.println("Smallest element is:"+obj.findSmallestElement(obj.arr));
		scan.close();
	}

}
