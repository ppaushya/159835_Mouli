package org.capgemini.com;
import java.util.*;
public class TestArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//declaration of array
		short mynum=43;
		double pi=3.14;
		//int[] num=new int[10];
		//int num[];int []num;
		int[] num= {1,2,3,4,5,6,7,8};
		num[0]=2;
		num[1]=mynum;
		num[2]=(int)pi;
		num[3]=45;
		num[7]=5;
	//	System.out.println(num);
		for(int i=0;i<8;i++)
		{
			System.out.println(num[i]);
		}

	}

}
