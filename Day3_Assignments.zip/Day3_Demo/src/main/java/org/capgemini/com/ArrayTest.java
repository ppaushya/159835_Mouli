package org.capgemini.com;

public class ArrayTest {

	public int[] getElements(int[] myarr)
	{
		for(int i=0;i<myarr.length;i++)
		{
			System.out.print(myarr[i]+2+", ");
		}
		System.out.println();
		return myarr;
	}
	public void printElements(int[] myarr)
	{
		for(int i=0;i<myarr.length;i++)
		{
			System.out.print(myarr[i]+", ");
		}
		System.out.println();
	}
	public int[] addArray(int[] array1,int[] array2)
	{
		int[] ans=new int[4];
		for(int i=0;i<4;i++)
		{
			ans[i]=array1[i]+array2[i];
		}
		return ans;
	}
	public void printData(int...arr)
	{
		for(int value:arr)
		{
			System.out.print(value+" ");
		}
	}
	public static void main(String[] args) {
		//  Auto-generated method stub
		int[] nums= {12,34,56,78,0,2};
		ArrayTest obj=new ArrayTest();
		obj.printElements(nums);
		obj.getElements(nums);
		int[] testnums=new int[nums.length];
		testnums=obj.getElements(nums);
		obj.printElements(testnums);
		int[] num1= {1,2,3,4};
		int[] num2= {10,20,30,40};
		int[] result=obj.addArray(num1, num2);
		for(int i=0;i<result.length;i++)
		{
			System.out.print(result[i]+", ");
		}
		obj.printData(result);

	}

}
