package org.capgemini.com;

import java.util.Scanner;

public class AddMul {
	
	public int[][] addArray(int[][] arr1,int[][] arr2,int row,int col)
	{
		int[][] ans=new int[row][col];
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				ans[i][j]=arr1[i][j]+arr2[i][j];
			}
		}
		return ans;
		
	}
	public int[][] mulArray(int[][] arr1,int[][] arr2,int r1,int c1,int r2,int c2)
	{
		int[][] ans=new int[r1][c2];
		for(int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                    ans[i][j] += arr1[i][k] * arr2[k][j];
                }
            }
        }
		
		return ans;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		AddMul ex=new AddMul();
		System.out.println("Enter the no.of rows and cols for Array 1");
		int r1=scan.nextInt();
		int c1=scan.nextInt();
		
		int[][] arr1=new int[r1][c1];
		System.out.println("Enter the elements of Array 1");

		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<c1;j++)
			{
				arr1[i][j]=scan.nextInt();
			}
		}
		System.out.println("Enter the no.of rows and cols for Array 2");
		int r2=scan.nextInt();
		int c2=scan.nextInt();
		
		int[][] arr2=new int[r1][c1];
		System.out.println("Enter the elements of Array 2");

		for(int i=0;i<r2;i++)
		{
			for(int j=0;j<c2;j++)
			{
				arr2[i][j]=scan.nextInt();
			}
		}
		if(r1==r2&&c1==c2)
		{
			System.out.println("Addition of 2 arrays:");
			int[][] res=ex.addArray(arr1,arr2,r1,c1);
			for(int i=0;i<r1;i++)
			{
				for(int j=0;j<c1;j++)
				{
					System.out.print(res[i][j]+" \t");
				}
				System.out.println();
			}
			
		}
		else 
		{
			System.out.println("For Addition the rows and colms of 2 arrays should be equal");
			System.exit(0);
		}
			
		if(c1==r2)
		{
			System.out.println("Multiplication of 2 arrays:");
			int[][] res1=ex.mulArray(arr1,arr2,r1,c1,r2,c2);
			for(int i=0;i<r1;i++)
			{
				for(int j=0;j<c2;j++)
				{
					System.out.print(res1[i][j]+" \t");
				}
				System.out.println();
			}
			
			
		}
		else
		{
			System.out.println("Check the size of array");
			System.exit(0);
		}

	}

}
