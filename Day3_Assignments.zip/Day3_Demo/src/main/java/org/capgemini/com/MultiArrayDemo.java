package org.capgemini.com;
import java.util.*;

public class MultiArrayDemo {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		//declaration
		int[][] arr;
		//initialization
		arr=new int[3][2];
		arr[0][0]=12;
		arr[0][1]=34;
		
		arr[1][0]=90;
		arr[1][1]=78;
		
		arr[2][0]=11;
		arr[2][1]=55;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(arr[i][j]);
			}
		}

			//another way of initialization
		int[][] arr1=new int[3][2];
		System.out.println("Enter elements");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				arr1[i][j]=scan.nextInt();
			}
		}
		System.out.println("Elements of 2nd array");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(arr1[i][j]+" \t");
			}
			System.out.println();
		}
		
	}

}
