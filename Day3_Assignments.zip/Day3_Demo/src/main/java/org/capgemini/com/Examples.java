package org.capgemini.com;
import java.util.*;
public class Examples {
	
	public void uppTriangle(int[][] arr,int rows,int cols)
	{
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				if(i>j)
					System.out.print(" \t");
				else
					System.out.print(arr[i][j]+" \t");
			}
			System.out.println();
		}
		
	}
	public void lowTriangle(int[][] arr,int rows,int cols)
	{
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<=i;j++)
			{
					System.out.print(arr[i][j]+" \t");
			}
			System.out.println();
		}
		
	}
	public void transposeMat(int[][] arr,int rows,int cols)
	{
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				System.out.print(arr[j][i]+" \t");
			}
			System.out.println();
		}
		
	}
public int sumArray(int[][] arr,int rows,int cols)
{
	int[] sum = new int[rows];
	int small=0;

	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			sum[i]=sum[i]+arr[i][j];
		}
		//System.out.println(sum[i]);

		small=sum[0];
    	for(int j=1;j<rows;j++)
    	{
    		if(small>sum[j])
    		{
    			small=sum[i];
    		}
    	}
    	
	}
	
	return small;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		Examples ex=new Examples();
		System.out.println("Enter the no.of rows and cols");
		int r=scan.nextInt();
		int c=scan.nextInt();
		
		int[][] myarr=new int[r][c];
		System.out.println("Enter the elements");

		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				myarr[i][j]=scan.nextInt();
			}
		}
		if(r==c)
		{
		System.out.println("UpperTriangle is");
		ex.uppTriangle(myarr, r, c);
		
		System.out.println("LowerTriangle is");
		ex.lowTriangle(myarr, r, c);
		System.out.println("Transpose Matrix is");
		ex.transposeMat(myarr, r, c);
		
		}
		
		else
			{
			 System.out.println("Enter the equal no.of rows and cols");
		     System.exit(0);
			}
		System.out.println("Least sum is"+ex.sumArray(myarr, r, c));
		scan.close();
		}

}
