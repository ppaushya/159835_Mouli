package org.capgemini.com;
import java.util.*;

public class Employee {

	 String firstName,lastName;
	 int empId,age,salary;
	 Employee temp;
	 Employee[] emp=new Employee[5];
	 Scanner scan=new Scanner(System.in);
	 public void getEmpDetails()
	 {
		 
		 System.out.println("Enter the employee details:");
		 firstName=scan.next();
		 lastName=scan.next();
		 empId=scan.nextInt();
		 age=scan.nextInt();
		 salary=scan.nextInt();
		
	 }
	 public void printDetails()
	 {
		 System.out.println(" Employee details are:");
		 
		 System.out.println("FirstName: "+firstName);
		 System.out.println("LastName: "+lastName);
		 System.out.println("EmployeeId: "+empId);
		 System.out.println("Age: "+age);
		 System.out.println("Salary: "+salary);
		 
	 }
	 public void sortEmployee(Employee[] emp)
	 {
		
		 for(int i=0;i<emp.length;i++)
	    	{
	    		for(int j=i+1;j<emp.length;j++)
	    		{
	    			if(emp[j].empId<emp[i].empId)
	    		  {
	    			temp=emp[i];
	    			emp[i]=emp[j];
	    		emp[j]=temp;
	    		  }
	    			
	    		}
	    		
	    	}
	 }
	 
	 
	public static void main(String[] args) {
	
		 System.out.println(" Enter the size");
		 
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
	Employee obj=new Employee();
		 Employee[] emp=new Employee[n];
		for(int i=0;i<n;i++)
		{
			emp[i]=new Employee();
			emp[i].getEmpDetails();
			//emp[i].sortEmployee();
			//emp[i].printDetails();
			// System.out.println("---------Enter the details again--------");
		}
		obj.sortEmployee(emp);
		 System.out.println("-----------------");
		for(int i=0;i<n;i++)
		{
			
			emp[i].printDetails();
			
		}
	

	}

}

