package org.capgemini.com;
import java.util.*;

public class StrArray {

	
	String[] mystr,temp;
	String temp1;
	
	
	public void acceptString(int size)
	{
		mystr=new String[size];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter "+size+"elements");
		for(int i=0;i<size;i++)
		{
			mystr[i]=sc.next();
		}
		sc.close();
	}
	public void printString()
	{
		for(int i=0;i<mystr.length;i++)
		{
			System.out.println(mystr[i]);
		}
	}
	
	public void revString(int size)
	{
		 
		    	int j=0;
		    	 temp=new String[size];
		    	for(int i=size-1;i>=0;i--,j++)
		    	{
		    		temp[j]=mystr[i];
		    		
		    		
		    	}
		    
	}
	public void sortString()
	{
		for(int i=0;i<mystr.length;i++)
    	{
    		for(int j=i+1;j<mystr.length;j++)
    		{
    			if(mystr[j].compareTo(mystr[i])<0)
    		  {
    			temp1=mystr[i];
    			mystr[i]=mystr[j];
    			mystr[j]=temp1;
    		  }
    			
    		}
    		
    	}
		
	}
	public static void main(String[] args) {
		
		StrArray st=new StrArray();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n=s.nextInt();
		st.acceptString(n);
		st.printString();
		System.out.println("Reversed array is");
		st.revString(n);
		for(int i=0;i<n;i++)
		{
			System.out.println(st.temp[i]);
		}
		
		
		st.sortString();
		
		System.out.println("Sorted Array in ascending order");
		for(int i=0;i<n;i++)
		{
			
			System.out.println(st.mystr[i]);	
		}
	}

}
