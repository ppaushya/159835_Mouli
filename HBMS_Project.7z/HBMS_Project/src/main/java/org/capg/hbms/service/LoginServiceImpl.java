package org.capg.hbms.service;

import org.capg.hbms.dao.ILoginDao;
import org.capg.hbms.dao.LoginDaoImpl;
import org.capg.hbms.model.Users;

public class LoginServiceImpl implements ILoginService{

	ILoginDao loginDao=new LoginDaoImpl();
	@Override
	public Users getUser(Users user) {
		
		return loginDao.getUser(user);
	}

}
