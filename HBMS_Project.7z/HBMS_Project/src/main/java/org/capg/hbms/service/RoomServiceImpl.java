package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.dao.IRoomDao;
import org.capg.hbms.dao.RoomDaoImpl;
import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.RoomDetails;

public class RoomServiceImpl implements IRoomService{
	IRoomDao roomdao=new RoomDaoImpl();
	@Override
	public void addRoom(RoomDetails room) {
		
		roomdao.addRoom(room);
	}

	@Override
	public List<RoomDetails> getRooms(int hotel_id) {
		
		return  roomdao.getRooms( hotel_id);
	}

	@Override
	public Double roomRate(int roomid) {
		
		return roomdao.roomRate(roomid);
	}

	@Override
	public void changeAvailability(RoomDetails finalroom) {
	
		roomdao.changeAvailability(finalroom);
	}

	@Override
	public RoomDetails getRoom_withID(int room_id) {
		// TODO Auto-generated method stub
		return roomdao.getRoom_withID(room_id);
	}

}
