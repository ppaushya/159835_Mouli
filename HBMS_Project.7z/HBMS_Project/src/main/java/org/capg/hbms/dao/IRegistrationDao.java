package org.capg.hbms.dao;

import org.capg.hbms.model.Users;

public interface IRegistrationDao {
	
	public Users createUser(Users user);

}
