package org.capg.hbms.service;

import org.capg.hbms.model.BookingDetails;

public interface IBookingService {
	public void addbooking(BookingDetails bookingdetails);
	public BookingDetails findAmount(BookingDetails bookingDetails,int count);
	
}
