package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.model.Hotel;

public interface IHotelService {
	public void addHotel(Hotel hotel);
	public List<Hotel> getHotels(String City);
	public void deleteHotel(int hotelid);
}
