package org.capg.hbms.view;

import java.util.Scanner;

import org.capg.hbms.model.Hotel;

public class AdminInteraction {
	Scanner sc=new Scanner(System.in);
public Hotel PromptHotel()
{
	Hotel hotel=new Hotel();
	System.out.println("Enter city");
	hotel.setCity(sc.next());
	System.out.println("Enter Hotel name");
	hotel.setHotel_name(sc.next());
	System.out.println("Enter Address");
	hotel.setAddress(sc.next());
	System.out.println("Enter description");
	hotel.setDescription(sc.next());
	System.out.println("Enter phone no ");
	hotel.setPhone_no1(sc.next());
	System.out.println("Enter alternate phone number");
	hotel.setPhone_no2(sc.next());
	System.out.println("Enter Average cost per night");
	hotel.setAvg_rate_per_night(sc.nextDouble());
	System.out.println("Enter rating");
	hotel.setRating(sc.next());
	System.out.println("Enter email");
	hotel.setEmail(sc.next());
	System.out.println("Enter fax");
	hotel.setFax(sc.next());
	return hotel;
	
}
public int DeleteHotel()
{
	System.out.println("Enter the id of the hotel u want to delete ");
	int id=sc.nextInt();
	return id;
}
public int modifyHotel()
{
	System.out.println("choose what you want to modify.");
	System.out.println("1.Description");
	System.out.println("2.Hotel Name");
	System.out.println("3.Average Rate per night");
	int choice =sc.nextInt();
	return choice;
	
}
}
