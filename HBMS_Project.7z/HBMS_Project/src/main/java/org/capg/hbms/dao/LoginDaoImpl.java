package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capg.hbms.model.Users;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public Users getUser(Users user) {
		
		String sql="select * from Users where email=? and password=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1, user.getEmail());
			statement.setString(2, user.getPassword());
		
		  ResultSet res=statement.executeQuery();
		if(res.next())
			{
				Users user1 =new Users();
				user1.setUser_id(res.getInt(1));
				user1.setPassword(res.getString(2));
				user1.setRole(res.getString(3));
				user1.setUser_name(res.getString(4));
				user1.setMobile_no(res.getString(5));
				user1.setPhone(res.getString(6));
				user1.setAddress(res.getString(7));
				user1.setEmail(res.getString(8));
				return user1;
				
			}
		else
		{
			System.out.println("You need to register first!");
			System.exit(0);//else go to home screen
		}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}
	

}
